El archivo bot.py original (4,588 líneas) no está disponible en este entorno.
Fue reemplazado por la refactorización modular en el paquete bot/.
