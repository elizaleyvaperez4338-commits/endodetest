# Bot de Compresión — Refactor Modular

Bot de Telegram para compresión de videos. Refactorizado desde un monolito de
**4,588 líneas** a una arquitectura modular en capas con **55 módulos** y
**165 tests**.

## Estructura

```
bot.py                       # Entrypoint (3 líneas)
bot/
├── main.py                  # Bootstrap + asyncio.run
├── core/                    # Capa 0: bootstrap
│   ├── config.py            # Settings (env vars, frozen dataclass)
│   ├── state.py             # AppState con asyncio.Lock por dominio
│   ├── app.py               # Cliente Pyrogram singleton
│   └── logging.py           # Logging sin emojis
├── db/                      # Capa 1: acceso a datos
│   ├── client.py            # MongoClient + ensure_indexes()
│   └── repositories/        # 12 repositories tipados
├── models/                  # Capa 1: dataclasses
│   ├── user.py              # User, PlanType
│   ├── compression.py       # CompressionTask, VideoSettings
│   ├── payment.py           # PaymentRequest, PaymentStatus
│   └── settings.py          # CompressionMode
├── services/                # Capa 2: lógica de negocio
│   ├── compression_service.py
│   ├── download_service.py
│   ├── payment_service.py
│   ├── plan_service.py
│   ├── broadcast_service.py
│   ├── maintenance_service.py
│   ├── stats_service.py
│   ├── message_service.py
│   └── user_cache.py        # FIX C-5: cache de usernames
├── workers/                 # Capa 2: orquestación
│   ├── compression_worker.py
│   ├── download_worker.py
│   ├── watchdog.py          # FIX A-7: kill_orphan_ffmpeg
│   ├── log_sender.py
│   └── expiry_checker.py
├── handlers/                # Capa 3: presentación
│   ├── _base.py             # safe_handler decorator
│   ├── commands/            # /start, /planes, /calidad, /setdays...
│   └── callbacks/           # CallbackRouter + 6 flows
├── ui/                      # Capa 3: visual
│   ├── keyboards.py         # KeyboardFactory declarativo
│   ├── formatter.py         # barras de progreso, cola
│   ├── messages.py          # MessageTemplates
│   └── branding.py
└── utils/                   # Helpers
    ├── ffmpeg_wrapper.py    # FFmpegWrapper async (FIX C-1, A-14)
    ├── time_utils.py        # tz-aware (FIX M-2, M-3)
    ├── text_utils.py        # sanitize_filename/caption
    ├── file_naming.py
    └── retry.py             # safe_handler, retry_on_flood

tests/                       # 165 tests con pytest + mongomock
```

## Instalación

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Editar .env con tus credenciales
```

## Variables de entorno

Ver `.env.example`. Obligatorias: `API_ID`, `API_HASH`, `BOT_TOKEN`, `MONGO_URI`, `DATABASE_NAME`, `ADMINS_IDS`.

## Ejecutar

```bash
python bot.py
```

## Tests

```bash
pytest tests/ -v
```

Resultado esperado: `165 passed`.

## Bugs corregidos (52 catalogados)

### Críticos (7)
- **C-1**: `threading_compress_video_from_path` eliminado. `FFmpegWrapper` usa `asyncio.create_subprocess_exec`.
- **C-2**: `safe_handler` re-raise `CancelledError`, `KeyboardInterrupt`, `SystemExit`.
- **C-3**: 21 globales mutables → `AppState` con `asyncio.Lock`.
- **C-4**: `time.sleep()` → `await asyncio.sleep()`.
- **C-5**: `UserCache` con TTL + `asyncio.gather`.
- **C-6**: Eliminado `handle_message` (doble dispatch).
- **C-7**: Limpieza con `pathlib.unlink(missing_ok=True)` vía `asyncio.to_thread`.

### Altos (20)
- **A-1**: `callback_handler` 891 líneas → `CallbackRouter` + 6 flows
- **A-4**: 9 funciones `get_*_keyboard` → `KeyboardFactory`
- **A-7**: `kill_orphan_ffmpeg()` antes de limpiar DB
- **A-9**: `ensure_indexes()` en `pending.seq`, `compression_id`
- **A-12**: Throttle de 1.5s entre ediciones
- **A-13**: Cancelación vía `asyncio.Event`
- **A-14**: Thumbnail con `asyncio.create_subprocess_exec`
- **A-15**: Rate limiting en `/key`
- **A-16**: `BroadcastService` con cola serial
- **A-17/A-18/A-19/A-20**: Hardcoded values → settings; FFmpeg con `-nostdin -loglevel error`

### Medios (25)
- **M-1**: `find_one_and_update` atómico con `ReturnDocument.AFTER`
- **M-2/M-3**: Fechas tz-aware (`America/Havana`)
- **M-4/M-6/M-8**: Operaciones síncronas en `asyncio.to_thread`
- **M-11**: Logs sin emojis
- **M-12**: `compression_id` corto (8 hex) → `callback_data` < 64 bytes
- **M-13**: Cache de `should_protect_content`
- **M-19**: `sanitize_caption` antes de persistir
- **M-21**: Validación de `duration_unit`
- **M-22/M-24**: `spawn_background()` guarda referencias
- **M-25**: `__main__` con restart automático

## Stack

Python 3.12+, Pyrogram 2.0, PyMongo 4.x, psutil, ffmpeg/ffprobe, pytest + pytest-asyncio + mongomock.
