import datetime as dt
from bot.utils.time_utils import format_time, sizeof_fmt, now_cuba, today_str, format_eta


class TestFormatTime:
    def test_zero(self): assert format_time(0) == "00:00"
    def test_negative(self): assert format_time(-5) == "00:00"
    def test_none(self): assert format_time(None) == "00:00"
    def test_string(self): assert format_time("abc") == "00:00"
    def test_seconds(self): assert format_time(45) == "00:45"
    def test_minutes(self): assert format_time(125) == "02:05"
    def test_hours(self): assert format_time(3661) == "01:01:01"
    def test_float(self): assert format_time(45.7) == "00:45"


class TestSizeofFmt:
    def test_bytes(self): assert sizeof_fmt(512) == "512.00B"
    def test_kb(self): assert "KB" in sizeof_fmt(1024)
    def test_mb(self): assert "MB" in sizeof_fmt(1024*1024)
    def test_gb(self): assert "GB" in sizeof_fmt(1024*1024*1024)
    def test_zero(self): assert sizeof_fmt(0) == "0.00B"


class TestTimezone:
    def test_now_cuba_tz_aware(self):
        n = now_cuba()
        assert n.tzinfo is not None

    def test_today_str_format(self):
        s = today_str()
        parts = s.split("-")
        assert len(parts) == 3
        assert all(p.isdigit() for p in parts)

    def test_format_eta_none(self):
        assert format_eta(None) == "Sin calcular..."

    def test_format_eta_past(self):
        past = now_cuba() - dt.timedelta(minutes=5)
        assert format_eta(past) == "Calculando..."

    def test_format_eta_future(self):
        future = now_cuba() + dt.timedelta(hours=2)
        r = format_eta(future)
        assert "AM" in r or "PM" in r
