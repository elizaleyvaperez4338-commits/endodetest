from bot.utils.file_naming import unique_compressed_path, unique_download_path


class TestUniqueCompressedPath:
    def test_basic(self, tmp_path):
        p = unique_compressed_path("video.mp4", str(tmp_path))
        assert p.suffix == ".mp4"
        assert p.parent == tmp_path
        assert not p.exists()

    def test_with_suffix(self, tmp_path):
        p = unique_compressed_path("video.mp4", str(tmp_path), suffix="_compressed")
        assert "_compressed" in p.name

    def test_avoids_collision(self, tmp_path):
        p1 = unique_compressed_path("video.mp4", str(tmp_path), suffix="")
        p1.touch()
        p2 = unique_compressed_path("video.mp4", str(tmp_path), suffix="")
        assert p1 != p2

    def test_sanitizes(self, tmp_path):
        p = unique_compressed_path("video@#$%.mp4", str(tmp_path))
        assert "@" not in p.name


class TestUniqueDownloadPath:
    def test_includes_cid(self, tmp_path):
        p = unique_download_path("abc123", "video.mp4", str(tmp_path))
        assert "abc123" in p.name
        assert p.suffix == ".mp4"

    def test_preserves_ext(self, tmp_path):
        p = unique_download_path("cid", "video.mkv", str(tmp_path))
        assert p.suffix == ".mkv"
