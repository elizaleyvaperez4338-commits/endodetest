import asyncio, os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
os.environ.setdefault("API_ID", "12345")
os.environ.setdefault("API_HASH", "testhash")
os.environ.setdefault("BOT_TOKEN", "123:abc")
os.environ.setdefault("MONGO_URI", "mongodb://localhost:27017")
os.environ.setdefault("DATABASE_NAME", "compress_bot_test")
os.environ.setdefault("ADMINS_IDS", "111,222")
os.environ.setdefault("BOT_TEMP_DIR", "/tmp/bot_test")
import pytest


def pytest_collection_modifyitems(items):
    asyncio_marker = pytest.mark.asyncio
    for item in items:
        if asyncio.iscoroutinefunction(getattr(item, "function", None)):
            item.add_marker(asyncio_marker)
