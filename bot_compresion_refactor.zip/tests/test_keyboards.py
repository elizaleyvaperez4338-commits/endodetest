from bot.ui.keyboards import KeyboardFactory, get_main_menu_keyboard, get_cancel_keyboard


class TestQualityStep:
    def test_resolution_custom(self):
        kb = KeyboardFactory.quality_step("resolution")
        assert kb is not None
        assert len(kb.inline_keyboard) >= 2

    def test_video_cb_data_short(self, tmp_path):
        cid = "abc12345"
        kb = KeyboardFactory.quality_step("resolution", compression_id=cid)
        for row in kb.inline_keyboard:
            for btn in row:
                assert len(btn.callback_data) <= 64

    def test_crf_has_multiple_rows(self):
        kb = KeyboardFactory.quality_step("crf")
        assert len(kb.inline_keyboard) >= 3

    def test_selected_shows_check(self):
        kb = KeyboardFactory.quality_step("crf", selected="28")
        found = any("✔️" in btn.text and "28" in btn.text for row in kb.inline_keyboard for btn in row)
        assert found

    def test_video_has_cancel(self):
        kb = KeyboardFactory.quality_step("resolution", compression_id="cid")
        last = kb.inline_keyboard[-1]
        assert any("Cancelar" in btn.text for btn in last)


class TestMenus:
    def test_quality_menu_5(self):
        kb = KeyboardFactory.quality_menu()
        assert len(kb.inline_keyboard) == 5

    def test_plan_menu_3(self):
        kb = KeyboardFactory.plan_menu()
        assert len(kb.inline_keyboard) == 3

    def test_payment_methods_4(self):
        kb = KeyboardFactory.payment_methods("premium")
        assert len(kb.inline_keyboard) == 4


class TestMainKb:
    def test_is_reply(self):
        from pyrogram.types import ReplyKeyboardMarkup
        kb = get_main_menu_keyboard()
        assert isinstance(kb, ReplyKeyboardMarkup)

    def test_6_buttons(self):
        kb = get_main_menu_keyboard()
        assert sum(len(r) for r in kb.keyboard) == 6


class TestCancelKb:
    def test_cb_short(self):
        cid = "abc12345"
        kb = get_cancel_keyboard(cid)
        for row in kb.inline_keyboard:
            for btn in row:
                assert len(btn.callback_data) <= 64
                assert cid in btn.callback_data
