import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from bot.utils.ffmpeg_wrapper import FFmpegWrapper, FFmpegError
from bot.models.compression import VideoSettings


class TestBuildCmd:
    def test_nostdin(self):
        cmd = FFmpegWrapper()._build_compress_command("/in.mp4", "/out.mp4", VideoSettings())
        assert "-nostdin" in cmd

    def test_loglevel_error(self):
        cmd = FFmpegWrapper()._build_compress_command("/in.mp4", "/out.mp4", VideoSettings())
        i = cmd.index("-loglevel")
        assert cmd[i+1] == "error"

    def test_crf(self):
        cmd = FFmpegWrapper()._build_compress_command("/in.mp4", "/out.mp4", VideoSettings(crf="32"))
        i = cmd.index("-crf")
        assert cmd[i+1] == "32"

    def test_scale(self):
        cmd = FFmpegWrapper()._build_compress_command("/in.mp4", "/out.mp4", VideoSettings(resolution="-2:720"))
        i = cmd.index("-vf")
        assert "scale=-2:720" in cmd[i+1]


class TestDrawtext:
    def test_none_if_font_missing(self):
        with patch("os.path.exists", return_value=False):
            assert FFmpegWrapper()._build_drawtext_filter() is None

    def test_includes_fontfile_when_present(self):
        with patch("os.path.exists", return_value=True):
            r = FFmpegWrapper()._build_drawtext_filter()
            if r: assert "fontfile=" in r and "drawtext=" in r


class TestProbe:
    async def test_zero_on_failure(self):
        with patch("asyncio.create_subprocess_exec", side_effect=Exception("no ffmpeg")):
            assert await FFmpegWrapper().probe_duration("/nope.mp4") == 0.0


class TestCompress:
    async def test_raises_on_missing_input(self):
        with pytest.raises(FFmpegError, match="Input file not found"):
            await FFmpegWrapper().compress("/nope.mp4", "/tmp/out.mp4", VideoSettings())


class TestCleanup:
    async def test_removes_files(self, tmp_path):
        f1 = tmp_path/"a.mp4"; f2 = tmp_path/"b.mp4"
        f1.write_text("x"); f2.write_text("y")
        await FFmpegWrapper().cleanup_files(str(f1), str(f2))
        assert not f1.exists() and not f2.exists()

    async def test_ignores_nonexistent(self, tmp_path):
        await FFmpegWrapper().cleanup_files(str(tmp_path/"nope.mp4"))

    async def test_handles_none(self, tmp_path):
        await FFmpegWrapper().cleanup_files(None, "", str(tmp_path/"x.mp4"))


class TestThumbnail:
    async def test_none_on_failure(self, tmp_path):
        with patch("asyncio.create_subprocess_exec", side_effect=Exception("fail")):
            assert await FFmpegWrapper().generate_thumbnail("/in.mp4", str(tmp_path/"t.jpg"), 10.0) is None
