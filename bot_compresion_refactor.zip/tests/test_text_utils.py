from bot.utils.text_utils import sanitize_filename, sanitize_caption, escape_html


class TestSanitizeFilename:
    def test_simple(self):
        assert sanitize_filename("video.mp4") == "video_mp4"
    def test_empty(self):
        assert sanitize_filename("") == "video_comprimido"
    def test_accents(self):
        r = sanitize_filename("vídeo canción")
        assert "í" not in r and "ó" not in r
    def test_special_chars(self):
        r = sanitize_filename("video@#$%name")
        assert "@" not in r and "_" in r
    def test_max_length(self):
        r = sanitize_filename("a"*200, max_length=50)
        assert len(r) <= 50
    def test_collapses_underscores(self):
        r = sanitize_filename("a   b   c")
        assert "__" not in r


class TestSanitizeCaption:
    def test_empty(self): assert sanitize_caption("") == ""
    def test_none(self): assert sanitize_caption(None) == ""
    def test_strips_control(self):
        r = sanitize_caption("hello\x00world")
        assert "\x00" not in r
    def test_preserves_newlines(self):
        r = sanitize_caption("line1\nline2")
        assert "\n" in r
    def test_strips_accents(self):
        r = sanitize_caption("café")
        assert "é" not in r


class TestEscapeHtml:
    def test_lt_gt(self): assert escape_html("<script>") == "&lt;script&gt;"
    def test_amp(self): assert escape_html("a & b") == "a &amp; b"
    def test_none(self): assert escape_html(None) == ""
    def test_empty(self): assert escape_html("") == ""
