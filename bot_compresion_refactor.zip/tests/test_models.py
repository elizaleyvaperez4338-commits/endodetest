import datetime as dt
from bot.models.compression import CompressionTask, CompressionId, VideoSettings, generate_compression_id
from bot.models.user import User, PlanType, PLAN_DURATIONS
from bot.models.payment import PaymentRequest, PaymentStatus, PaymentMethod
from bot.models.settings import CompressionMode


class TestCompressionId:
    def test_8_chars(self):
        assert len(generate_compression_id()) == 8

    def test_hex(self):
        cid = generate_compression_id()
        assert all(c in "0123456789abcdef" for c in cid)

    def test_unique(self):
        ids = {generate_compression_id() for _ in range(1000)}
        assert len(ids) == 1000

    def test_class(self):
        assert len(str(CompressionId.new())) == 8


class TestVideoSettings:
    def test_defaults(self):
        s = VideoSettings()
        assert s.resolution and s.crf

    def test_from_dict_overrides(self):
        s = VideoSettings.from_dict({"crf":"30"})
        assert s.crf == "30"

    def test_from_dict_ignores_unknown(self):
        s = VideoSettings.from_dict({"unknown":"x","crf":"32"})
        assert s.crf == "32"
        assert not hasattr(s, "unknown")

    def test_to_dict_roundtrip(self):
        s1 = VideoSettings(crf="35", fps="30")
        s2 = VideoSettings.from_dict(s1.to_dict())
        assert s2.crf == "35" and s2.fps == "30"

    def test_parse_command(self):
        s = VideoSettings.parse_command("resolution=-2:720 crf=25")
        assert s.resolution == "-2:720" and s.crf == "25"

    def test_parse_command_invalid_key_ignored(self):
        s = VideoSettings.parse_command("invalid=x crf=30")
        assert s.crf == "30"

    def test_parse_command_empty_raises(self):
        import pytest
        with pytest.raises(ValueError):
            VideoSettings.parse_command("")


class TestUser:
    def test_no_plan(self):
        assert not User(user_id=123).is_active

    def test_plan_no_expiry(self):
        assert User(user_id=123, plan="ultra").is_active

    def test_future_expiry(self):
        f = dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=7)
        assert User(user_id=123, plan="premium", expires_at=f).is_active

    def test_past_expiry(self):
        p = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=1)
        assert not User(user_id=123, plan="premium", expires_at=p).is_active

    def test_from_doc(self):
        u = User.from_doc({"user_id":123,"plan":"pro","compressed_videos":5})
        assert u.user_id == 123 and u.plan == "pro" and u.compressed_videos == 5


class TestPayment:
    def test_from_doc(self):
        from bson import ObjectId
        oid = ObjectId()
        p = PaymentRequest.from_doc({"_id":oid,"user_id":123,"plan":"premium","method":"usdt","status":"pending_admin"})
        assert p.user_id == 123 and p.status == PaymentStatus.PENDING_ADMIN and p._id == oid


class TestCompressionMode:
    def test_values(self):
        assert CompressionMode.BEFORE.value == "before"
        assert CompressionMode.AFTER.value == "after"


class TestTask:
    def test_to_worker_dict(self):
        t = CompressionTask(compression_id="abc12345", user_id=123, original_video_path="/tmp/v.mp4", file_name="v.mp4", chat_id=123, original_message_id=1)
        d = t.to_worker_dict()
        assert d["compression_id"] == "abc12345" and d["custom_settings"] is None
