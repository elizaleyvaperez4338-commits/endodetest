import importlib


MODULES = [
    "bot","bot.core","bot.core.config","bot.core.logging","bot.core.app","bot.core.state",
    "bot.models","bot.models.user","bot.models.compression","bot.models.payment","bot.models.settings",
    "bot.db","bot.db.client","bot.db.repositories",
    "bot.utils","bot.utils.time_utils","bot.utils.text_utils","bot.utils.file_naming","bot.utils.ffmpeg_wrapper","bot.utils.retry",
    "bot.ui","bot.ui.keyboards","bot.ui.formatter","bot.ui.messages","bot.ui.branding",
    "bot.services","bot.services.maintenance_service","bot.services.stats_service","bot.services.message_service","bot.services.user_cache","bot.services.compression_service","bot.services.download_service","bot.services.plan_service","bot.services.payment_service","bot.services.broadcast_service",
    "bot.workers","bot.workers.compression_worker","bot.workers.download_worker","bot.workers.watchdog","bot.workers.log_sender","bot.workers.expiry_checker",
    "bot.handlers","bot.handlers._base","bot.handlers.commands","bot.handlers.commands.user","bot.handlers.commands.admin",
    "bot.handlers.callbacks","bot.handlers.callbacks.router","bot.handlers.callbacks.quality_flow","bot.handlers.callbacks.payment_flow","bot.handlers.callbacks.plan_flow","bot.handlers.callbacks.queue_flow","bot.handlers.callbacks.admin_flow","bot.handlers.callbacks.main_flow",
    "bot.main",
]


def test_all_modules_import():
    failures = []
    for m in MODULES:
        try: importlib.import_module(m)
        except Exception as e: failures.append((m, str(e)))
    assert not failures, "Módulos que fallaron:\n" + "\n".join(f"  - {m}: {e}" for m, e in failures)


def test_settings_loaded():
    from bot.core.config import settings
    assert settings.api_id == 12345
    assert settings.version == "32.0.0"


def test_callback_router_has_handlers():
    from bot.handlers.callbacks.router import callback_router
    assert len(callback_router._handlers) > 0
    prefixes = [p for p, _ in callback_router._handlers]
    assert "custom_" in prefixes
    assert "pay_plan_" in prefixes
    assert "plan_" in prefixes
    assert "cancel_task_" in prefixes


def test_ffmpeg_wrapper_includes_nostdin():
    from bot.utils.ffmpeg_wrapper import FFmpegWrapper
    from bot.models.compression import VideoSettings
    cmd = FFmpegWrapper()._build_compress_command("/in.mp4", "/out.mp4", VideoSettings())
    assert "-nostdin" in cmd
    assert "-loglevel" in cmd
