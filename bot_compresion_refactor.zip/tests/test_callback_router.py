import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock
from bot.handlers.callbacks.router import CallbackRouter
from bot.core.state import app_state


class TestRouter:
    async def test_register_dispatch(self):
        r = CallbackRouter()
        h = AsyncMock()
        r.register("custom_", h)
        q = MagicMock()
        q.data = "custom_resolution_480"
        q.from_user.id = 123
        await r.dispatch(MagicMock(), q)
        h.assert_called_once()

    async def test_unknown_returns_invalid(self):
        r = CallbackRouter()
        q = MagicMock()
        q.data = "unknown_cb"
        q.from_user.id = 123
        q.answer = AsyncMock()
        await r.dispatch(MagicMock(), q)
        q.answer.assert_called_once()

    async def test_maintenance_blocks_non_admin(self):
        r = CallbackRouter()
        h = AsyncMock()
        r.register("test_", h)
        await app_state.set_maintenance(True)
        try:
            q = MagicMock()
            q.data = "test_action"
            q.from_user.id = 999
            q.answer = AsyncMock()
            await r.dispatch(MagicMock(), q)
            h.assert_not_called()
            q.answer.assert_called_once()
        finally:
            await app_state.set_maintenance(False)

    async def test_maintenance_allows_admin(self):
        r = CallbackRouter()
        h = AsyncMock()
        r.register("test_", h)
        await app_state.set_maintenance(True)
        try:
            q = MagicMock()
            q.data = "test_action"
            q.from_user.id = 111
            q.answer = AsyncMock()
            await r.dispatch(MagicMock(), q)
            h.assert_called_once()
        finally:
            await app_state.set_maintenance(False)

    async def test_specific_prefix_wins(self):
        r = CallbackRouter()
        g = AsyncMock(); s = AsyncMock()
        r.register("custom_", g)
        r.register("custom_resolution_", s)
        q = MagicMock()
        q.data = "custom_resolution_480"
        q.from_user.id = 111
        await r.dispatch(MagicMock(), q)
        s.assert_called_once()
        g.assert_not_called()

    async def test_handler_exception_no_crash(self):
        r = CallbackRouter()
        h = AsyncMock(side_effect=ValueError("boom"))
        r.register("test_", h)
        q = MagicMock()
        q.data = "test_action"
        q.from_user.id = 111
        await r.dispatch(MagicMock(), q)
        h.assert_called_once()
