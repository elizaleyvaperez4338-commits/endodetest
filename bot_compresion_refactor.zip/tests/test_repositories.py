import datetime as dt
import pytest
import mongomock
from bot.db.repositories import (CountersRepository, PendingRepository, UsersRepository, BannedRepository, PaymentsRepository, TempKeysRepository, AccessDeniedLogRepository)


@pytest.fixture
async def mock_db():
    client = mongomock.MongoClient()
    db = client["test"]
    import bot.db.client as cm
    import bot.db.repositories as rm
    from bot.db.repositories import (DownloadedVideosRepository, ActiveCompressionsRepository, UserSettingsRepository, DailyStatsRepository, PendingConfirmationsRepository)
    original = {"db":cm.db,"users_repo":rm.users_repo,"pending_repo":rm.pending_repo,"downloaded_videos_repo":rm.downloaded_videos_repo,"active_compressions_repo":rm.active_compressions_repo,"payments_repo":rm.payments_repo,"temp_keys_repo":rm.temp_keys_repo,"banned_repo":rm.banned_repo,"user_settings_repo":rm.user_settings_repo,"daily_stats_repo":rm.daily_stats_repo,"counters_repo":rm.counters_repo,"access_denied_log_repo":rm.access_denied_log_repo,"pending_confirmations_repo":rm.pending_confirmations_repo}
    cm.db = db
    rm.users_repo = UsersRepository(db)
    rm.pending_repo = PendingRepository(db)
    rm.counters_repo = CountersRepository(db)
    rm.banned_repo = BannedRepository(db)
    rm.payments_repo = PaymentsRepository(db)
    rm.temp_keys_repo = TempKeysRepository(db)
    rm.downloaded_videos_repo = DownloadedVideosRepository(db)
    rm.active_compressions_repo = ActiveCompressionsRepository(db)
    rm.user_settings_repo = UserSettingsRepository(db)
    rm.daily_stats_repo = DailyStatsRepository(db)
    rm.access_denied_log_repo = AccessDeniedLogRepository(db)
    rm.pending_confirmations_repo = PendingConfirmationsRepository(db)
    yield db
    cm.db = original["db"]
    for k, v in original.items():
        if k != "db": setattr(rm, k, v)


class TestCounters:
    async def test_starts_at_1(self, mock_db):
        r = CountersRepository(mock_db)
        assert await r.next_seq() == 1
        assert await r.next_seq() == 2

    async def test_concurrent_safe(self, mock_db):
        import asyncio
        r = CountersRepository(mock_db)
        results = await asyncio.gather(*[r.next_seq() for _ in range(10)])
        assert len(set(results)) == 10


class TestPending:
    async def test_add_returns_seq(self, mock_db):
        r = PendingRepository(mock_db)
        assert await r.add({"compression_id":"c1","user_id":123}) == 1

    async def test_position_of(self, mock_db):
        r = PendingRepository(mock_db)
        await r.add({"compression_id":"c1","user_id":123})
        await r.add({"compression_id":"c2","user_id":123})
        await r.add({"compression_id":"c3","user_id":123})
        assert await r.position_of("c2") == 2

    async def test_position_nonexistent(self, mock_db):
        assert await PendingRepository(mock_db).position_of("nope") == 0

    async def test_remove(self, mock_db):
        r = PendingRepository(mock_db)
        await r.add({"compression_id":"c1","user_id":123})
        assert await r.remove("c1") is True
        assert await r.position_of("c1") == 0


class TestUsers:
    async def test_set_plan_creates(self, mock_db):
        r = UsersRepository(mock_db)
        await r.set_plan(123, "premium", expires_at=dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=30))
        u = await r.get(123)
        assert u is not None and u["plan"] == "premium"

    async def test_increment(self, mock_db):
        r = UsersRepository(mock_db)
        await r.set_plan(123, "premium")
        await r.increment_compressed(123)
        await r.increment_compressed(123)
        assert (await r.get(123))["compressed_videos"] == 2


class TestBanned:
    async def test_ban_unban(self, mock_db):
        r = BannedRepository(mock_db)
        await r.ban(123)
        assert any(b["user_id"]==123 for b in await r.all())
        assert await r.unban(123) is True
        assert not any(b["user_id"]==123 for b in await r.all())


class TestTempKeys:
    async def test_create_find(self, mock_db):
        r = TempKeysRepository(mock_db)
        exp = dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=30)
        await r.create("K1","premium",30,"days",exp)
        k = await r.find_valid("K1")
        assert k is not None and k["plan"] == "premium"

    async def test_excludes_used(self, mock_db):
        r = TempKeysRepository(mock_db)
        exp = dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=30)
        await r.create("K1","premium",30,"days",exp)
        kd = await r.find_valid("K1")
        await r.mark_used(kd["_id"])
        assert await r.find_valid("K1") is None


class TestAccessDenied:
    async def test_first_allows(self, mock_db):
        assert await AccessDeniedLogRepository(mock_db).can_notify(123) is True

    async def test_second_blocks(self, mock_db):
        r = AccessDeniedLogRepository(mock_db)
        await r.can_notify(123, cooldown=300)
        assert await r.can_notify(123, cooldown=300) is False
