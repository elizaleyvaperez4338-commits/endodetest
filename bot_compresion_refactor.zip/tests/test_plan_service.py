import datetime as dt
import pytest
import mongomock
from bot.services.plan_service import PlanService


@pytest.fixture
async def mock_db():
    client = mongomock.MongoClient()
    db = client["test"]
    import bot.db.client as cm
    import bot.db.repositories as rm
    from bot.db.repositories import (UsersRepository, TempKeysRepository, CountersRepository, DownloadedVideosRepository, ActiveCompressionsRepository, PaymentsRepository, BannedRepository, UserSettingsRepository, DailyStatsRepository, AccessDeniedLogRepository, PendingConfirmationsRepository)
    original = {"db":cm.db,"users_repo":rm.users_repo,"temp_keys_repo":rm.temp_keys_repo,"counters_repo":rm.counters_repo,"downloaded_videos_repo":rm.downloaded_videos_repo,"active_compressions_repo":rm.active_compressions_repo,"payments_repo":rm.payments_repo,"banned_repo":rm.banned_repo,"user_settings_repo":rm.user_settings_repo,"daily_stats_repo":rm.daily_stats_repo,"access_denied_log_repo":rm.access_denied_log_repo,"pending_confirmations_repo":rm.pending_confirmations_repo,"pending_repo":rm.pending_repo}
    cm.db = db
    rm.users_repo = UsersRepository(db)
    rm.temp_keys_repo = TempKeysRepository(db)
    rm.counters_repo = CountersRepository(db)
    rm.downloaded_videos_repo = DownloadedVideosRepository(db)
    rm.active_compressions_repo = ActiveCompressionsRepository(db)
    rm.payments_repo = PaymentsRepository(db)
    rm.banned_repo = BannedRepository(db)
    rm.user_settings_repo = UserSettingsRepository(db)
    rm.daily_stats_repo = DailyStatsRepository(db)
    rm.access_denied_log_repo = AccessDeniedLogRepository(db)
    rm.pending_confirmations_repo = PendingConfirmationsRepository(db)
    rm.pending_repo = rm.PendingRepository(db)
    yield db
    cm.db = original["db"]
    for k, v in original.items():
        if k != "db": setattr(rm, k, v)


class TestActivateKey:
    async def test_invalid(self, mock_db):
        ok, info = await PlanService().activate_key(123, "INVALID")
        assert ok is False and info == "invalid"

    async def test_expired(self, mock_db):
        from bot.db.repositories import temp_keys_repo
        past = dt.datetime.now(dt.timezone.utc)-dt.timedelta(days=1)
        await temp_keys_repo.create("EXP","premium",30,"days",past)
        ok, info = await PlanService().activate_key(123, "EXP")
        assert ok is False and info == "expired"

    async def test_invalid_unit(self, mock_db):
        from bot.db.repositories import temp_keys_repo
        f = dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=30)
        await temp_keys_repo.create("K1","premium",1,"months",f)
        ok, _ = await PlanService().activate_key(123, "K1")
        assert ok is False

    async def test_valid_days(self, mock_db):
        from bot.db.repositories import temp_keys_repo
        f = dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=30)
        await temp_keys_repo.create("V","premium",30,"days",f)
        ok, info = await PlanService().activate_key(123, "V")
        assert ok is True and info == "premium"

    async def test_valid_hours(self, mock_db):
        from bot.db.repositories import temp_keys_repo
        f = dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=30)
        await temp_keys_repo.create("H","standard",12,"hours",f)
        ok, info = await PlanService().activate_key(123, "H")
        assert ok is True and info == "standard"

    async def test_valid_minutes(self, mock_db):
        from bot.db.repositories import temp_keys_repo
        f = dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=30)
        await temp_keys_repo.create("M","pro",60,"minutes",f)
        ok, info = await PlanService().activate_key(123, "M")
        assert ok is True and info == "pro"

    async def test_marked_used(self, mock_db):
        from bot.db.repositories import temp_keys_repo
        f = dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=30)
        await temp_keys_repo.create("ONCE","premium",30,"days",f)
        await PlanService().activate_key(123, "ONCE")
        ok, info = await PlanService().activate_key(456, "ONCE")
        assert ok is False and info == "invalid"


class TestIsActive:
    async def test_no_plan(self, mock_db):
        assert await PlanService().is_active(123) is False

    async def test_active_plan(self, mock_db):
        from bot.db.repositories import users_repo
        f = dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=7)
        await users_repo.set_plan(123, "premium", f)
        assert await PlanService().is_active(123) is True

    async def test_expired_plan(self, mock_db):
        from bot.db.repositories import users_repo
        p = dt.datetime.now(dt.timezone.utc)-dt.timedelta(days=1)
        await users_repo.set_plan(123, "premium", p)
        assert await PlanService().is_active(123) is False

    async def test_ultra_no_expiry(self, mock_db):
        from bot.db.repositories import users_repo
        await users_repo.set_plan(123, "ultra", None)
        assert await PlanService().is_active(123) is True


class TestQueueLimit:
    async def test_no_plan(self, mock_db):
        assert await PlanService().get_queue_limit(123) == 1

    async def test_premium(self, mock_db):
        from bot.db.repositories import users_repo
        from bot.core.config import settings
        f = dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=7)
        await users_repo.set_plan(123, "premium", f)
        assert await PlanService().get_queue_limit(123) == settings.premium_queue_limit
