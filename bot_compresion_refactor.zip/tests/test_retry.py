import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from bot.utils.retry import retry_on_flood, safe_handler
import pyrogram.errors


class TestRetryFlood:
    async def test_success_first(self):
        calls = 0
        @retry_on_flood(max_retries=3)
        async def f():
            nonlocal calls; calls += 1
            return "ok"
        assert await f() == "ok"
        assert calls == 1

    async def test_retries_then_succeeds(self):
        calls = 0
        @retry_on_flood(max_retries=3)
        async def f():
            nonlocal calls; calls += 1
            if calls < 2: raise pyrogram.errors.FloodWait(value=0)
            return "ok"
        with patch("asyncio.sleep", new_callable=AsyncMock):
            assert await f() == "ok"
        assert calls == 2

    async def test_exhausts_retries(self):
        @retry_on_flood(max_retries=2)
        async def f():
            raise pyrogram.errors.FloodWait(value=0)
        with patch("asyncio.sleep", new_callable=AsyncMock):
            with pytest.raises(pyrogram.errors.FloodWait):
                await f()


class TestSafeHandler:
    async def test_success(self):
        @safe_handler
        async def h(c, m): return "ok"
        assert await h(MagicMock(), MagicMock()) == "ok"

    async def test_swallows_message_not_modified(self):
        @safe_handler
        async def h(c, m): raise pyrogram.errors.MessageNotModified()
        await h(MagicMock(), MagicMock())

    async def test_swallows_message_id_invalid(self):
        @safe_handler
        async def h(c, m): raise pyrogram.errors.MessageIdInvalid()
        await h(MagicMock(), MagicMock())

    async def test_reraises_cancelled(self):
        @safe_handler
        async def h(c, m): raise asyncio.CancelledError()
        with pytest.raises(asyncio.CancelledError):
            await h(MagicMock(), MagicMock())

    async def test_reraises_keyboard_interrupt(self):
        @safe_handler
        async def h(c, m): raise KeyboardInterrupt()
        with pytest.raises(KeyboardInterrupt):
            await h(MagicMock(), MagicMock())

    async def test_swallows_generic(self):
        @safe_handler
        async def h(c, m): raise ValueError("boom")
        await h(MagicMock(), MagicMock())

    async def test_notifies_user(self):
        mc = MagicMock()
        mc.send_message = AsyncMock()
        mm = MagicMock()
        mm.chat.id = 123
        @safe_handler
        async def h(c, m): raise ValueError("boom")
        await h(mc, mm)
        mc.send_message.assert_called_once()
