from bot.ui.formatter import create_compression_bar, create_mini_progress_bar, format_queue_status


class TestBars:
    def test_zero(self):
        assert "0%" in create_compression_bar(0)
        assert "⬡" in create_compression_bar(0)

    def test_full(self):
        assert "100%" in create_compression_bar(100)
        assert "⬢" in create_compression_bar(100)

    def test_clamps_above(self):
        assert "100%" in create_compression_bar(150)

    def test_clamps_below(self):
        assert "0%" in create_compression_bar(-10)

    def test_mini(self):
        b = create_mini_progress_bar(50)
        assert "[" in b and "]" in b and "50%" in b


class TestFormatQueue:
    async def test_empty(self):
        t = await format_queue_status([], [], [], {})
        assert "Estado de la cola" in t
        assert "Ninguna" in t or "Ninguno" in t

    async def test_with_active(self):
        active = [{"compression_id":"c1","user_id":123,"file_name":"v.mp4"}]
        pm = {"c1":{"stage":"compression","percent":50}}
        t = await format_queue_status(active, [], [], pm)
        assert "1/1" in t
        assert "123" in t

    async def test_with_downloaded(self):
        d = [{"compression_id":"c1","user_id":123,"file_name":"v.mp4"}]
        t = await format_queue_status([], d, [], {})
        assert "Usuario 123" in t

    async def test_admin_view(self):
        t = await format_queue_status([], [], [], {}, is_admin=True)
        assert "Vista de administrador" in t

    async def test_user_view_no_admin(self):
        t = await format_queue_status([], [], [], {}, is_admin=False)
        assert "Vista de administrador" not in t
