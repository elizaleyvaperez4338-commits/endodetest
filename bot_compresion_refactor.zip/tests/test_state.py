import asyncio
import pytest
from bot.core.state import AppState


@pytest.fixture
def state():
    return AppState()


class TestCancelable:
    async def test_register_unregister(self, state):
        await state.register_cancelable("c1", "download")
        assert not await state.is_cancelled("c1")
        await state.unregister_cancelable("c1")
        assert await state.is_cancelled("c1")

    async def test_unregister_nonexistent_safe(self, state):
        await state.unregister_cancelable("nope")

    async def test_get_cancelable_none(self, state):
        assert await state.get_cancelable("nope") is None

    async def test_cancel_nonexistent_false(self, state):
        assert await state.cancel_task("nope") is False


class TestProgress:
    async def test_update_get(self, state):
        await state.update_progress("c1", "compression", 50, 100, 50, "v.mp4")
        p = await state.get_progress("c1")
        assert p is not None and p.percent == 50

    async def test_remove(self, state):
        await state.update_progress("c1", "download")
        await state.remove_progress("c1")
        assert await state.get_progress("c1") is None

    async def test_remove_nonexistent_safe(self, state):
        await state.remove_progress("nope")


class TestMessages:
    async def test_set_get(self, state):
        await state.set_active_message("c1", 12345)
        assert await state.get_active_message("c1") == 12345

    async def test_remove(self, state):
        await state.set_active_message("c1", 12345)
        await state.remove_active_message("c1")
        assert await state.get_active_message("c1") is None


class TestMaintenance:
    async def test_default_false(self, state):
        assert await state.get_maintenance() is False

    async def test_activate(self, state):
        await state.set_maintenance(True)
        assert await state.get_maintenance() is True

    async def test_deactivate(self, state):
        await state.set_maintenance(True)
        await state.set_maintenance(False)
        assert await state.get_maintenance() is False


class TestBanned:
    async def test_ban_check(self, state):
        await state.ban_user(123)
        assert await state.is_banned(123) is True
        assert await state.is_banned(456) is False

    async def test_unban(self, state):
        await state.ban_user(123)
        await state.unban_user(123)
        assert await state.is_banned(123) is False

    async def test_unban_nonexistent_safe(self, state):
        await state.unban_user(999)


class TestTrackCompression:
    async def test_cleanup_on_exit(self, state):
        async with state.track_compression("c1"):
            await state.register_cancelable("c1", "ffmpeg")
            await state.update_progress("c1", "compression", 50)
            await state.set_active_message("c1", 999)
        assert await state.get_cancelable("c1") is None
        assert await state.get_progress("c1") is None
        assert await state.get_active_message("c1") is None


class TestThrottle:
    def test_first_call_false(self, state):
        assert state.should_throttle("k1") is False

    def test_second_call_true(self, state):
        state.should_throttle("k2")
        assert state.should_throttle("k2") is True

    def test_different_keys(self, state):
        state.should_throttle("kA")
        assert state.should_throttle("kB") is False


class TestSpawn:
    async def test_spawn_complete(self, state):
        async def dummy():
            await asyncio.sleep(0.01)
            return 42
        t = state.spawn_background(dummy())
        assert await t == 42

    async def test_task_removed_after_complete(self, state):
        async def dummy():
            await asyncio.sleep(0.01)
        t = state.spawn_background(dummy())
        await t
        await asyncio.sleep(0.01)
        assert t not in state._background_tasks
