"""Flujo de calidad."""
from __future__ import annotations
from pyrogram import Client
from pyrogram.types import CallbackQuery
from bot.core.state import app_state
from bot.db.repositories import user_settings_repo
from bot.services.message_service import MessageService
from bot.ui.keyboards import KeyboardFactory


class QualityFlow:
    async def handle(self, client, query):
        data = query.data
        uid = query.from_user.id
        if data == "custom_quality_start":
            await self._show_resolution(query, uid); return
        if data.startswith("custom_resolution_"):
            res = data.replace("custom_resolution_", "")
            app_state.set_temp_custom_settings(uid, {**app_state.get_temp_custom_settings(uid), "resolution": res})
            await self._show_crf(query, uid); return
        if data == "custom_next_crf":
            await self._show_crf(query, uid); return
        if data.startswith("custom_crf_"):
            crf = data.replace("custom_crf_", "")
            app_state.set_temp_custom_settings(uid, {**app_state.get_temp_custom_settings(uid), "crf": crf})
            await self._show_fps(query, uid); return
        if data == "custom_back_resolution":
            await self._show_resolution(query, uid); return
        if data == "custom_next_fps":
            await self._show_fps(query, uid); return
        if data.startswith("custom_fps_"):
            fps = data.replace("custom_fps_", "")
            app_state.set_temp_custom_settings(uid, {**app_state.get_temp_custom_settings(uid), "fps": fps})
            await self._show_audio(query, uid); return
        if data == "custom_back_crf":
            await self._show_crf(query, uid); return
        if data == "custom_next_audio":
            await self._show_audio(query, uid); return
        if data.startswith("custom_audio_"):
            audio = data.replace("custom_audio_", "")
            app_state.set_temp_custom_settings(uid, {**app_state.get_temp_custom_settings(uid), "audio_bitrate": audio})
            await self._show_audio(query, uid, selected=audio); return
        if data == "custom_back_fps":
            await self._show_fps(query, uid); return
        if data == "custom_finish":
            await self._finish(query, uid); return

    async def handle_video(self, client, query):
        data = query.data
        parts = data.split("_")
        if len(parts) < 4:
            await query.answer("Datos inválidos.", show_alert=True)
            return
        action = parts[1]; cid = parts[2]
        if action == "cancel":
            app_state.del_temp_config(cid)
            await query.message.edit_text("❌ Configuración cancelada.")
            return
        if action in ("res","crf","fps","audio"):
            value = parts[3] if len(parts) > 3 else None
            config = app_state.get_temp_config(cid)
            fm = {"res":"resolution","crf":"crf","fps":"fps","audio":"audio_bitrate"}
            if value: config[fm[action]] = value
            app_state.set_temp_config(cid, config)
            sm = {"res":"resolution","crf":"crf","fps":"fps","audio":"audio"}
            await self._show_video_step(query, cid, sm[action]); return
        if action == "back":
            sf = {"res":"resolution","crf":"crf","fps":"fps","audio":"audio"}
            await self._show_video_step(query, cid, sf.get(parts[1].replace("back","").lower(), "resolution")); return
        if action == "next":
            sf = {"crf":"crf","fps":"fps","audio":"audio"}
            await self._show_video_step(query, cid, sf.get(parts[1].replace("next","").lower(), "crf")); return
        if action == "finish":
            await self._finish_video(query, cid); return

    async def _show_resolution(self, query, uid, selected=None):
        kb = KeyboardFactory.quality_step("resolution", selected=selected)
        await query.message.edit_text("⚙️**CONFIGURAR CALIDAD - PASO 1/4**⚙️\n\nSelecciona la resolución:", reply_markup=kb)

    async def _show_crf(self, query, uid):
        sel = app_state.get_temp_custom_settings(uid).get("crf")
        kb = KeyboardFactory.quality_step("crf", selected=sel)
        await query.message.edit_text("⚙️**CONFIGURAR CALIDAD - PASO 2/4**⚙️\n\nSelecciona el nivel de compresión CRF:\n➥Menor valor = mejor calidad (archivo más grande)\n➥Mayor valor = menor calidad (archivo más pequeño)", reply_markup=kb)

    async def _show_fps(self, query, uid):
        sel = app_state.get_temp_custom_settings(uid).get("fps")
        kb = KeyboardFactory.quality_step("fps", selected=sel)
        await query.message.edit_text("⚙️**CONFIGURAR CALIDAD - PASO 3/4**⚙️\n\nSelecciona el FPS:", reply_markup=kb)

    async def _show_audio(self, query, uid, selected=None):
        if selected is None: selected = app_state.get_temp_custom_settings(uid).get("audio_bitrate")
        kb = KeyboardFactory.quality_step("audio", selected=selected)
        await query.message.edit_text("⚙️**CONFIGURAR CALIDAD - PASO 4/4**⚙️\n\nSelecciona la calidad de audio:", reply_markup=kb)

    async def _finish(self, query, uid):
        s = app_state.get_temp_custom_settings(uid)
        if not s or len(s) < 4:
            await query.answer("Debes completar todos los pasos.", show_alert=True)
            return
        from bot.models.compression import VideoSettings
        ns = VideoSettings.from_dict(s)
        await user_settings_repo.set_video_settings(uid, ns)
        app_state.del_temp_custom_settings(uid)
        await query.message.edit_text(f"✅ **Configuración guardada correctamente**\n\n• Resolución: `{ns.resolution}`\n• CRF: `{ns.crf}`\n• FPS: `{ns.fps}`\n• Audio: `{ns.audio_bitrate}`")
        await query.answer("✅ Guardado")

    async def _show_video_step(self, query, cid, step):
        config = app_state.get_temp_config(cid)
        sel = config.get(step)
        kb = KeyboardFactory.quality_step(step, compression_id=cid, selected=sel)
        titles = {"resolution":("PASO 1/4","Selecciona la resolución:"),"crf":("PASO 2/4","Selecciona el nivel de compresión CRF:"),"fps":("PASO 3/4","Selecciona el FPS:"),"audio":("PASO 4/4","Selecciona la calidad de audio:")}
        sn, desc = titles.get(step, ("PASO","Selecciona:"))
        await query.message.edit_text(f"⚙️ **CONFIGURAR CALIDAD PARA ESTE VIDEO - {sn}**\n\n{desc}", reply_markup=kb)

    async def _finish_video(self, query, cid):
        config = app_state.get_temp_config(cid)
        if not config or len(config) < 4:
            await query.answer("Debes completar todos los pasos.", show_alert=True)
            return
        await query.message.edit_text("✅ **Configuración aplicada a este video**\n\nIniciando descarga...")
        await query.answer("✅ Iniciando")


quality_flow = QualityFlow()
