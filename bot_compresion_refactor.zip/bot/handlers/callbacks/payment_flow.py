"""Flujo de pagos."""
from __future__ import annotations
from bson import ObjectId
from pyrogram import Client
from pyrogram.types import CallbackQuery
from bot.services.message_service import MessageService
from bot.services.payment_service import PaymentService
from bot.ui.keyboards import KeyboardFactory
from bot.ui.messages import MessageTemplates


PLAN_DESCRIPTIONS = {
    "standard": "🧩 **Plan Estándar**\n\n• Compresión ilimitada\n• Cola hasta 2 videos\n• Duración: 7 días\n\nPrecio: 50 CUP",
    "pro": "💎 **Plan Pro**\n\n• Compresión ilimitada\n• Cola hasta 4 videos\n• Prioridad en cola\n• Duración: 15 días\n\nPrecio: 100 CUP",
    "premium": "👑 **Plan Premium**\n\n• Compresión ilimitada\n• Cola hasta 10 videos\n• Máxima prioridad\n• Soporte prioritario\n• Duración: 30 días\n\nPrecio: 200 CUP",
}


class PaymentFlow:
    def __init__(self):
        self._service = PaymentService()
        self._messages = MessageService()

    async def handle_pay_plan(self, client, query):
        plan = query.data.split("_")[2]
        kb = KeyboardFactory.payment_methods(plan)
        await query.message.edit_text("**Seleccione método de Pago:**", reply_markup=kb)

    async def handle_method(self, client, query):
        parts = query.data.split("_")
        method = parts[2]; plan = parts[3]
        uid = query.from_user.id
        pid = await self._service.create_request(uid, plan, method)
        if method == "usdt": msg = MessageTemplates.payment_request_usdt()
        elif method == "mtransfer": msg = "➥ **Pago vía MiTransfer**\n\nCuenta: `12345678901`\nTitular: CompressFast"
        elif method == "saldo": msg = "➥ **Pago vía Saldo Móvil**\n\nNúmero: `+5355555555`"
        else: msg = "Método no soportado."
        kb = KeyboardFactory.verify_payment(pid)
        await query.message.edit_text(msg, reply_markup=kb)

    async def handle_verify(self, client, query):
        pid_str = query.data.replace("verify_payment_", "")
        try: pid = ObjectId(pid_str)
        except Exception:
            await query.answer("ID de pago inválido.", show_alert=True)
            return
        await query.message.edit_text("📸 **Sube el comprobante de pago**\n\nEnvía una foto del comprobante. Se revisará en breve.")
        await query.answer("Esperando comprobante")

    async def handle_back_to_methods(self, client, query):
        parts = query.data.split("_")
        plan = "standard"
        if len(parts) >= 5: plan = parts[4]
        kb = KeyboardFactory.payment_methods(plan)
        await query.message.edit_text("**Seleccione método de Pago:**", reply_markup=kb)


payment_flow = PaymentFlow()
