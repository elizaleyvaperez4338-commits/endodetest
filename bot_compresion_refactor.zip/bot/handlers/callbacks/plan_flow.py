"""Flujo de planes."""
from __future__ import annotations
from pyrogram import Client
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from bot.services.message_service import MessageService
from bot.ui.keyboards import KeyboardFactory
from bot.ui.messages import MessageTemplates


class PlanFlow:
    def __init__(self):
        self._messages = MessageService()

    async def handle_plan(self, client, query):
        plan = query.data.split("_")[1]
        from bot.handlers.callbacks.payment_flow import PLAN_DESCRIPTIONS
        desc = PLAN_DESCRIPTIONS.get(plan, "Plan no encontrado.")
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Volver", callback_data="plan_back"), InlineKeyboardButton("💳 PAGAR AHORA", callback_data=f"pay_plan_{plan}")]])
        await query.message.edit_text(desc, reply_markup=kb)

    async def handle_show_plans(self, client, query):
        kb = KeyboardFactory.plan_menu()
        await query.message.edit_text(MessageTemplates.plan_no_active(), reply_markup=kb)

    async def handle_back(self, client, query):
        kb = KeyboardFactory.plan_menu()
        await query.message.edit_text("📋 **Selecciona un plan para más información:**", reply_markup=kb)


plan_flow = PlanFlow()
