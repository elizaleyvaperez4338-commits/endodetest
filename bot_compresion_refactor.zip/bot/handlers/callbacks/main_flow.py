"""Flujo principal."""
from __future__ import annotations
from pyrogram import Client
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from bot.db.repositories import user_settings_repo
from bot.ui.keyboards import KeyboardFactory


class MainFlow:
    async def handle_mode(self, client, query):
        mode = query.data.replace("mode_", "")
        await user_settings_repo.set_compression_mode(query.from_user.id, mode)
        mt = "al enviar video" if mode == "after" else "antes de enviar video"
        await query.message.edit_text(f"**Configuración aplicada** ✅⚙️\n\nModo: **Configurar calidad {mt}**")
        await query.answer("✅ Modo actualizado")

    async def handle_custom_start(self, client, query):
        from bot.handlers.callbacks.quality_flow import quality_flow
        await quality_flow._show_resolution(query, query.from_user.id)

    async def handle_general_menu(self, client, query):
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("📉 Baja (más pequeño)", callback_data="preset_general_low")],[InlineKeyboardButton("📊 Media", callback_data="preset_general_medium")],[InlineKeyboardButton("📈 Alta (mejor calidad)", callback_data="preset_general_high")],[InlineKeyboardButton("🔙 Volver", callback_data="back_to_settings")]])
        await query.message.edit_text("🗜️ **Compresión General**\n\nSelecciona la calidad:", reply_markup=kb)

    async def handle_reels_menu(self, client, query):
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("📱 Vertical 360x640", callback_data="preset_reels_vertical")],[InlineKeyboardButton("🔙 Volver", callback_data="back_to_settings")]])
        await query.message.edit_text("📱 **Videos en Vertical**\n\nOptimizado para Reels/TikTok:", reply_markup=kb)

    async def handle_show_menu(self, client, query):
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("📺 Media", callback_data="preset_show_medium")],[InlineKeyboardButton("🔙 Volver", callback_data="back_to_settings")]])
        await query.message.edit_text("📺 **Shows / Calidad media**\n\nBalance entre tamaño y calidad:", reply_markup=kb)

    async def handle_anime_menu(self, client, query):
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🎬 Anime (baja)", callback_data="preset_anime_low")],[InlineKeyboardButton("🔙 Volver", callback_data="back_to_settings")]])
        await query.message.edit_text("🎬 **Anime y series animadas**\n\nOptimizado para animación:", reply_markup=kb)

    async def handle_back_to_settings(self, client, query):
        kb = KeyboardFactory.quality_menu()
        await query.message.edit_text("⚙️𝗦𝗲𝗹𝗲𝗰𝗰𝗶𝗼𝗻𝗮𝗿 𝗖𝗮𝗹𝗶𝗱𝗮𝗱⚙️", reply_markup=kb)


main_flow = MainFlow()
