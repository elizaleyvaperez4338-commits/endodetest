"""Flujo de cola."""
from __future__ import annotations
from pyrogram import Client
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from bot.core.state import app_state
from bot.db.repositories import active_compressions_repo, downloaded_videos_repo, pending_repo
from bot.ui.formatter import format_queue_status


class QueueFlow:
    async def handle_cancel_task(self, client, query):
        cid = query.data.replace("cancel_task_", "")
        ok = await app_state.cancel_task(cid)
        if ok:
            await query.answer("⛔ Cancelando...")
            try: await query.message.delete()
            except Exception: pass
        else:
            await query.answer("⚠️ No se encontró la tarea.", show_alert=True)

    async def handle_refresh_queue(self, client, query):
        uid = query.from_user.id
        from bot.core.config import settings
        is_admin = settings.is_admin(uid)
        active = await active_compressions_repo.list_all()
        downloaded = await downloaded_videos_repo.list_sorted()
        pending = await pending_repo.list_sorted()
        progress = await app_state.all_progress()
        pm = {k: {"stage":v.stage, "percent":v.percent} for k,v in progress.items()}
        text = await format_queue_status(active, downloaded, pending, pm, uid, is_admin)
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔄 Actualizar", callback_data="refresh_queue"), InlineKeyboardButton("❌ Cerrar", callback_data="close_queue")]])
        try: await query.message.edit_text(text, reply_markup=kb)
        except Exception: pass
        await query.answer("Actualizado")

    async def handle_close_queue(self, client, query):
        try: await query.message.delete()
        except Exception: pass

    async def handle_refresh_status(self, client, query):
        from bot.handlers.commands.admin import _get_system_stats
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔄 Actualizar", callback_data="refresh_status_stats")]])
        try:
            stats = await _get_system_stats()
            await query.message.edit_text(stats, reply_markup=kb)
        except Exception: pass
        await query.answer("Actualizado")


queue_flow = QueueFlow()
