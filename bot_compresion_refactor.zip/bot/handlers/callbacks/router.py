"""CallbackRouter. FIX A-1: reemplaza 891 líneas."""
from __future__ import annotations
from typing import Callable
from pyrogram import Client
from pyrogram.types import CallbackQuery
from bot.core.logging import logger
from bot.core.state import app_state
from bot.services.maintenance_service import MaintenanceService


class CallbackRouter:
    def __init__(self):
        self._handlers = []

    def register(self, prefix, handler):
        self._handlers.append((prefix, handler))
        self._handlers.sort(key=lambda x: -len(x[0]))

    async def dispatch(self, client, query):
        uid = query.from_user.id
        from bot.core.config import settings
        if not settings.is_admin(uid):
            m = MaintenanceService()
            if await m.is_active():
                await query.answer("🔧 Bot en mantenimiento\n\nPor favor, espere a que termine.", show_alert=True)
                return
        data = query.data or ""
        for prefix, handler in self._handlers:
            if data.startswith(prefix):
                try: await handler(client, query)
                except Exception as e: logger.exception(f"Error en callback handler: {e}")
                return
        await query.answer("Opción inválida.", show_alert=True)


callback_router = CallbackRouter()


def _register_all_flows():
    from bot.handlers.callbacks.quality_flow import quality_flow
    from bot.handlers.callbacks.payment_flow import payment_flow
    from bot.handlers.callbacks.plan_flow import plan_flow
    from bot.handlers.callbacks.queue_flow import queue_flow
    from bot.handlers.callbacks.admin_flow import admin_flow
    from bot.handlers.callbacks.main_flow import main_flow

    callback_router.register("custom_quality_start", main_flow.handle_custom_start)
    callback_router.register("custom_", quality_flow.handle)
    callback_router.register("vid_", quality_flow.handle_video)
    callback_router.register("pay_plan_", payment_flow.handle_pay_plan)
    callback_router.register("payment_method_", payment_flow.handle_method)
    callback_router.register("verify_payment_", payment_flow.handle_verify)
    callback_router.register("back_to_methods_", payment_flow.handle_back_to_methods)
    callback_router.register("plan_", plan_flow.handle_plan)
    callback_router.register("show_plans_from_start", plan_flow.handle_show_plans)
    callback_router.register("cancel_task_", queue_flow.handle_cancel_task)
    callback_router.register("refresh_queue", queue_flow.handle_refresh_queue)
    callback_router.register("close_queue", queue_flow.handle_close_queue)
    callback_router.register("refresh_status_stats", queue_flow.handle_refresh_status)
    callback_router.register("confirm_setdays_", admin_flow.handle_confirm_setdays)
    callback_router.register("cancel_setdays", admin_flow.handle_cancel_setdays)
    callback_router.register("admin_accept_payment_", admin_flow.handle_accept_payment)
    callback_router.register("admin_reject_payment_", admin_flow.handle_reject_payment)
    callback_router.register("mode_", main_flow.handle_mode)
    callback_router.register("general_menu", main_flow.handle_general_menu)
    callback_router.register("reels_menu", main_flow.handle_reels_menu)
    callback_router.register("show_menu", main_flow.handle_show_menu)
    callback_router.register("anime_menu", main_flow.handle_anime_menu)
    callback_router.register("back_to_settings", main_flow.handle_back_to_settings)
    callback_router.register("plan_back", plan_flow.handle_back)


_register_all_flows()
