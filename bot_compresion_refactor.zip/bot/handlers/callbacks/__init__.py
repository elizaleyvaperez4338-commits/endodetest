"""Callbacks."""
from bot.handlers.callbacks.router import CallbackRouter, callback_router
from bot.handlers.callbacks.quality_flow import QualityFlow
from bot.handlers.callbacks.payment_flow import PaymentFlow
from bot.handlers.callbacks.plan_flow import PlanFlow
from bot.handlers.callbacks.queue_flow import QueueFlow
from bot.handlers.callbacks.admin_flow import AdminFlow
from bot.handlers.callbacks.main_flow import MainFlow


def register_callbacks(app):
    from pyrogram import filters
    from bot.handlers._base import safe_handler

    @app.on_callback_query()
    @safe_handler
    async def _callback_handler(client, callback_query):
        await callback_router.dispatch(client, callback_query)
