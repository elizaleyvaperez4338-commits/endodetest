"""Flujo admin."""
from __future__ import annotations
from bson import ObjectId
from pyrogram import Client
from pyrogram.types import CallbackQuery
from bot.core.config import settings
from bot.services.payment_service import PaymentService


class AdminFlow:
    async def handle_confirm_setdays(self, client, query):
        if not settings.is_admin(query.from_user.id):
            await query.answer("No autorizado.", show_alert=True)
            return
        days_str = query.data.replace("confirm_setdays_", "")
        try: days = int(days_str)
        except ValueError:
            await query.answer("Días inválidos.", show_alert=True)
            return
        from bot.handlers.commands.admin import _apply_setdays
        u, f = await _apply_setdays(days, query.from_user.id)
        await query.message.edit_text(f"✅ **Días agregados a todos los usuarios**\n\n• Días: {days}\n• Actualizados: {u}\n• Fallidos: {f}")
        await query.answer("Completado")

    async def handle_cancel_setdays(self, client, query):
        await query.message.edit_text("❌ **Operación cancelada.**")
        await query.answer("Cancelado")

    async def handle_accept_payment(self, client, query):
        if not settings.is_admin(query.from_user.id):
            await query.answer("No autorizado.", show_alert=True)
            return
        pid_str = query.data.replace("admin_accept_payment_", "")
        try: pid = ObjectId(pid_str)
        except Exception:
            await query.answer("ID inválido.", show_alert=True)
            return
        ok, info = await PaymentService().admin_accept(pid)
        if ok:
            await query.message.edit_text(f"✅ **Plan {info.capitalize()} activado.**")
            await query.answer("Plan activado.")
        else:
            await query.answer("⚠️ No se pudo procesar.", show_alert=True)

    async def handle_reject_payment(self, client, query):
        if not settings.is_admin(query.from_user.id):
            await query.answer("No autorizado.", show_alert=True)
            return
        pid_str = query.data.replace("admin_reject_payment_", "")
        try: pid = ObjectId(pid_str)
        except Exception:
            await query.answer("ID inválido.", show_alert=True)
            return
        ok, info = await PaymentService().admin_reject(pid)
        if ok:
            await query.message.edit_text(f"❌ **Pago rechazado (plan {info.capitalize()}).**")
            await query.answer("Rechazado.")
        else:
            await query.answer("⚠️ No se pudo procesar.", show_alert=True)


admin_flow = AdminFlow()
