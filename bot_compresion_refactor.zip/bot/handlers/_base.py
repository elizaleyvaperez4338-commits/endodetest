"""Base de handlers. FIX C-2."""
from __future__ import annotations
import asyncio
from typing import Callable
import pyrogram.errors
from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from bot.core.config import settings
from bot.core.logging import logger
from bot.core.state import app_state
from bot.services.maintenance_service import MaintenanceService
from bot.services.message_service import MessageService


def safe_handler(func):
    async def wrapper(client, update, *args, **kwargs):
        try: return await func(client, update, *args, **kwargs)
        except asyncio.CancelledError: raise
        except (KeyboardInterrupt, SystemExit): raise
        except pyrogram.errors.FloodWait as e: await asyncio.sleep(e.value + 1)
        except pyrogram.errors.MessageNotModified: pass
        except pyrogram.errors.MessageIdInvalid: pass
        except pyrogram.errors.UserIsBlocked: pass
        except pyrogram.errors.RPCError as e: logger.error(f"Telegram RPC en {func.__name__}: {e}")
        except Exception:
            logger.exception(f"Error inesperado en {func.__name__}")
            try:
                chat = getattr(getattr(update, "message", update), "chat", None)
                if chat: await client.send_message(chat.id, "⚠️ Ocurrió un error inesperado. Intenta de nuevo.")
            except Exception: pass
    wrapper.__name__ = func.__name__
    wrapper.__doc__ = func.__doc__
    return wrapper


def register_all_handlers(app):
    from bot.handlers.commands import register_commands
    from bot.handlers.callbacks import register_callbacks
    register_commands(app)
    register_callbacks(app)
    logger.info("Handlers registrados")
