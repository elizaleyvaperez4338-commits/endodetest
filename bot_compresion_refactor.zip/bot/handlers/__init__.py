"""Handlers."""
from bot.handlers._base import safe_handler, register_all_handlers
from bot.handlers.callbacks.router import callback_router

__all__ = ["safe_handler","register_all_handlers","callback_router"]
