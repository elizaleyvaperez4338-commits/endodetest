"""Comandos."""
from bot.handlers.commands.user import (start_command, planes_command, calidad_command, reset_calidad_command, key_command, mode_command, my_plan_command, settings_menu, estado_command, queue_command, cancel_command, cancel_queue_command, ayuda_handler, show_queue_command)
from bot.handlers.commands.admin import (setdays_command, status_command, log_command, backup_command, getdb_command, restdb_command, banuser_command, desuser_command, deleteuser_command, viewban_command, setplan_command, userinfo_command, restuser_command, broadcast_command, broadcast_multimedia_command, cancel_broadcast_command, maintenance_on_command, maintenance_off_command, daily_stats_command, watchdog_status_command, restart_command, admin_stats_command, list_users_command, delete_all_pending, delete_one_from_pending, generate_key_command, list_keys_command, del_keys_command, manual_check_expiry_command, startup_command)


def register_commands(app):
    from pyrogram import filters
    from bot.core.config import settings
    from bot.handlers._base import safe_handler

    admins = filters.user(settings.admins_ids)

    @app.on_message(filters.command("start"))
    @safe_handler
    async def _start(c, m): await start_command(c, m)

    @app.on_message(filters.command("planes") & filters.private)
    @safe_handler
    async def _planes(c, m): await planes_command(c, m)

    @app.on_message(filters.command(["calidad","quality"]) & filters.private)
    @safe_handler
    async def _calidad(c, m): await calidad_command(c, m)

    @app.on_message(filters.command("resetcalidad") & filters.private)
    @safe_handler
    async def _reset_calidad(c, m): await reset_calidad_command(c, m)

    @app.on_message(filters.command("key") & filters.private)
    @safe_handler
    async def _key(c, m): await key_command(c, m)

    @app.on_message(filters.command("mode") & filters.private)
    @safe_handler
    async def _mode(c, m): await mode_command(c, m)

    @app.on_message(filters.command("myplan") & filters.private)
    @safe_handler
    async def _myplan(c, m): await my_plan_command(c, m)

    @app.on_message(filters.command("settings") & filters.private)
    @safe_handler
    async def _settings(c, m): await settings_menu(c, m)

    @app.on_message(filters.command("estado") & filters.private)
    @safe_handler
    async def _estado(c, m): await estado_command(c, m)

    @app.on_message(filters.command(["cola","queue"]) & filters.private)
    @safe_handler
    async def _cola(c, m): await queue_command(c, m)

    @app.on_message(filters.command("cancel") & filters.private)
    @safe_handler
    async def _cancel(c, m): await cancel_command(c, m)

    @app.on_message(filters.command("cancelqueue") & filters.private)
    @safe_handler
    async def _cancelqueue(c, m): await cancel_queue_command(c, m)

    @app.on_message(filters.command("setdays") & admins)
    @safe_handler
    async def _setdays(c, m): await setdays_command(c, m)

    @app.on_message(filters.command("status") & admins)
    @safe_handler
    async def _status(c, m): await status_command(c, m)

    @app.on_message(filters.command(["watchdog","whactdog"]) & admins)
    @safe_handler
    async def _watchdog(c, m): await watchdog_status_command(c, m)

    @app.on_message(filters.command("log") & admins)
    @safe_handler
    async def _log(c, m): await log_command(c, m)

    @app.on_message(filters.command("backup") & admins)
    @safe_handler
    async def _backup(c, m): await backup_command(c, m)

    @app.on_message(filters.command("getdb") & admins)
    @safe_handler
    async def _getdb(c, m): await getdb_command(c, m)

    @app.on_message(filters.command("restdb") & admins)
    @safe_handler
    async def _restdb(c, m): await restdb_command(c, m)

    @app.on_message(filters.command(["banuser","deluser"]) & admins)
    @safe_handler
    async def _banuser(c, m): await banuser_command(c, m)

    @app.on_message(filters.command("desuser") & admins)
    @safe_handler
    async def _desuser(c, m): await desuser_command(c, m)

    @app.on_message(filters.command("deleteuser") & admins)
    @safe_handler
    async def _deleteuser(c, m): await deleteuser_command(c, m)

    @app.on_message(filters.command("viewban") & admins)
    @safe_handler
    async def _viewban(c, m): await viewban_command(c, m)

    @app.on_message(filters.command("setplan") & admins)
    @safe_handler
    async def _setplan(c, m): await setplan_command(c, m)

    @app.on_message(filters.command("userinfo") & admins)
    @safe_handler
    async def _userinfo(c, m): await userinfo_command(c, m)

    @app.on_message(filters.command("restuser") & admins)
    @safe_handler
    async def _restuser(c, m): await restuser_command(c, m)

    @app.on_message(filters.command("msg") & admins)
    @safe_handler
    async def _msg(c, m): await broadcast_command(c, m)

    @app.on_message(filters.command("broadcast") & admins)
    @safe_handler
    async def _broadcast(c, m): await broadcast_multimedia_command(c, m)

    @app.on_message(filters.command("cancelbroadcast") & admins)
    @safe_handler
    async def _cancelbroadcast(c, m): await cancel_broadcast_command(c, m)

    @app.on_message(filters.command("man_on") & admins)
    @safe_handler
    async def _man_on(c, m): await maintenance_on_command(c, m)

    @app.on_message(filters.command("man_off") & admins)
    @safe_handler
    async def _man_off(c, m): await maintenance_off_command(c, m)

    @app.on_message(filters.command("ls") & admins)
    @safe_handler
    async def _ls(c, m): await daily_stats_command(c, m)

    @app.on_message(filters.command("restart") & admins)
    @safe_handler
    async def _restart(c, m): await restart_command(c, m)

    @app.on_message(filters.command("admin") & admins)
    @safe_handler
    async def _admin(c, m): await admin_stats_command(c, m)

    @app.on_message(filters.command(["user","users"]) & admins)
    @safe_handler
    async def _users(c, m): await list_users_command(c, m)

    @app.on_message(filters.command("deleteall") & admins)
    @safe_handler
    async def _deleteall(c, m): await delete_all_pending(c, m)

    @app.on_message(filters.command("generatekey") & admins)
    @safe_handler
    async def _genkey(c, m): await generate_key_command(c, m)

    @app.on_message(filters.command("listkeys") & admins)
    @safe_handler
    async def _listkeys(c, m): await list_keys_command(c, m)

    @app.on_message(filters.command("delkeys") & admins)
    @safe_handler
    async def _delkeys(c, m): await del_keys_command(c, m)

    @app.on_message(filters.command("checkexpiry") & admins)
    @safe_handler
    async def _checkexpiry(c, m): await manual_check_expiry_command(c, m)

    @app.on_message(filters.command("auto") & admins)
    @safe_handler
    async def _auto(c, m): await startup_command(c, m)
