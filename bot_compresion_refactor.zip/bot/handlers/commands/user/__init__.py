"""Comandos de usuario."""
from __future__ import annotations
import datetime as dt
import time
from typing import Optional
from pyrogram import Client
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
from bot.core.config import settings
from bot.core.logging import logger
from bot.core.state import app_state
from bot.db.repositories import pending_repo, downloaded_videos_repo, active_compressions_repo, user_settings_repo
from bot.services.maintenance_service import MaintenanceService
from bot.services.message_service import MessageService
from bot.services.plan_service import PlanService
from bot.ui.formatter import format_queue_status
from bot.ui.keyboards import get_main_menu_keyboard, get_quality_menu_keyboard, KeyboardFactory
from bot.ui.messages import MessageTemplates
from bot.utils.time_utils import now_cuba


async def start_command(client, message):
    uid = message.from_user.id
    m = MaintenanceService()
    if await m.check_and_notify(uid, message.chat.id, "start", MessageService().send_protected_message): return
    if await app_state.is_banned(uid): return
    if not await PlanService().is_active(uid):
        await MessageService().send_protected_message(message.chat.id, MessageTemplates.DENIED_ACCESS, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("💠Planes💠", callback_data="show_plans_from_start")]]))
        return
    await MessageService().send_protected_photo(chat_id=message.chat.id, photo="logo.jpg", caption=MessageTemplates.welcome(settings.version), reply_markup=get_main_menu_keyboard())


async def planes_command(client, message):
    ps = PlanService()
    doc = await ps.get_user_plan(message.from_user.id)
    if doc and doc.get("plan"):
        plan = doc["plan"].capitalize()
        exp = doc.get("expires_at")
        if exp:
            now = dt.datetime.now(exp.tzinfo) if exp.tzinfo else dt.datetime.now()
            if exp > now:
                rem = exp - now
                d = rem.days; h = rem.seconds // 3600
                exp_t = f"{d}d {h}h" if d > 0 else f"{h}h" if h > 0 else f"{rem.seconds//60}m"
            else: exp_t = "Expirado"
        else: exp_t = "No expira"
        text = MessageTemplates.plan_info(plan, exp_t)
    else:
        text = MessageTemplates.plan_no_active()
    await MessageService().send_protected_message(message.chat.id, text, reply_markup=KeyboardFactory.plan_menu())


async def calidad_command(client, message):
    uid = message.from_user.id
    if not await PlanService().is_active(uid):
        await MessageService().send_protected_message(message.chat.id, MessageTemplates.DENIED_ACCESS)
        return
    if len(message.text.split()) < 2:
        cur = await user_settings_repo.get_video_settings(uid)
        rd = cur.resolution.split("x")[1] if "x" in cur.resolution else cur.resolution
        await MessageService().send_protected_message(message.chat.id, f"**Tu configuración actual de compresión:**\n\n• **Resolución**: `{rd}`\n• **CRF**: `{cur.crf}`\n• **FPS**: `{cur.fps}`\n• **Bitrate de audio**: `{cur.audio_bitrate}`\n\nPara restablecer a la configuración por defecto, usa /resetcalidad")
        return
    cmd = message.text.split(maxsplit=1)[1]
    if await user_settings_repo.update_video_settings(uid, cmd):
        ns = await user_settings_repo.get_video_settings(uid)
        r = MessageTemplates.SETTINGS_UPDATED
        for k, v in ns.to_dict().items(): r += f"• **{k}**: `{v}`\n"
        await MessageService().send_protected_message(message.chat.id, r)
    else:
        await MessageService().send_protected_message(message.chat.id, MessageTemplates.SETTINGS_FORMAT_HELP)


async def reset_calidad_command(client, message):
    uid = message.from_user.id
    await user_settings_repo.reset_video_settings(uid)
    d = await user_settings_repo.get_video_settings(uid)
    rd = d.resolution.split("x")[1] if "x" in d.resolution else d.resolution
    await MessageService().send_protected_message(message.chat.id, f"✅ **Configuración restablecida a los valores por defecto:**\n\n• **resolución**: {rd}\n• **crf**: {d.crf}\n• **fps**: {d.fps}\n• **audio_bitrate**: {d.audio_bitrate}")


_key_attempts = {}


async def key_command(client, message):
    uid = message.from_user.id
    if await app_state.is_banned(uid):
        await MessageService().send_protected_message(message.chat.id, MessageTemplates.BANNED)
        return
    now = time.time()
    attempts = _key_attempts.get(uid, [])
    attempts = [t for t in attempts if now - t < 60]
    if len(attempts) >= settings.key_rate_limit_per_min:
        await MessageService().send_protected_message(message.chat.id, "⚠️ Demasiados intentos. Espera un minuto.")
        return
    attempts.append(now); _key_attempts[uid] = attempts
    if not message.text or len(message.text.split()) < 2:
        await MessageService().send_protected_message(message.chat.id, "❌ Formato: /key <clave>")
        return
    key = message.text.split()[1].strip()
    ps = PlanService()
    ok, info = await ps.activate_key(uid, key)
    if not ok:
        if info == "invalid": await MessageService().send_protected_message(message.chat.id, MessageTemplates.key_invalid())
        elif info == "expired": await MessageService().send_protected_message(message.chat.id, MessageTemplates.key_expired())
        else: await MessageService().send_protected_message(message.chat.id, "❌ **Error al activar el plan.**")
        return
    from bot.db.client import db
    doc = await db["temp_keys"].find_one({"key": key})
    if doc:
        dv = doc["duration_value"]; du = doc["duration_unit"]
        dt_text = f"{dv} {du}"
        if dv == 1: dt_text = dt_text[:-1]
    else: dt_text = ""
    await MessageService().send_protected_message(message.chat.id, MessageTemplates.plan_activated(info, dt_text))


async def mode_command(client, message):
    uid = message.from_user.id
    if not await PlanService().is_active(uid):
        await MessageService().send_protected_message(message.chat.id, MessageTemplates.DENIED_ACCESS)
        return
    cur = await user_settings_repo.get_compression_mode(uid)
    text = f"**Seleccione el modo de compresión:**\n\n{'✅' if cur=='after' else '❌'} • **Configurar calidad al enviar video**\n{'✅' if cur=='before' else '❌'} • **Configurar calidad antes de enviar video**\n\nElige el modo que prefieras para tus videos."
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("🛠️ Configurar calidad al enviar video", callback_data="mode_after")],[InlineKeyboardButton("⚙️ Configurar calidad antes de enviar video", callback_data="mode_before")]])
    await MessageService().send_protected_message(message.chat.id, text, reply_markup=kb)


async def my_plan_command(client, message):
    doc = await PlanService().get_user_plan(message.from_user.id)
    if not doc or not doc.get("plan"):
        await MessageService().send_protected_message(message.chat.id, MessageTemplates.DENIED_ACCESS)
        return
    await planes_command(client, message)


async def settings_menu(client, message):
    await MessageService().send_protected_message(message.chat.id, "⚙️𝗦𝗲𝗹𝗲𝗰𝗰𝗶𝗼𝗻𝗮𝗿 𝗖𝗮𝗹𝗶𝗱𝗮𝗱⚙️", reply_markup=get_quality_menu_keyboard())


async def estado_command(client, message):
    m = MaintenanceService()
    is_m = await m.is_active()
    if is_m:
        st = "⚙️ **BOT EN MANTENIMIENTO** ⚙️"
        desc = "➥El bot está actualmente en modo mantenimiento.\n\n**Vuelva a intentar más tarde.**"
    else:
        st = "✅ **BOT EN LÍNEA** ✅"
        desc = "➥El bot está funcionando normalmente.\n\n**Puede enviar videos para comprimir.**"
    r = f"{st}\n\n{desc}\n\n🕐 **Hora del servidor:** {now_cuba().strftime('%Y-%m-%d %H:%M:%S')}"
    if settings.is_admin(message.from_user.id):
        import psutil
        cpu = psutil.cpu_percent(interval=None)
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        r += f"\n\n👑 **Vista de administrador:**\n• **CPU:** {cpu:.1f}%\n• **RAM:** {ram.percent:.1f}%\n• **Disco:** {disk.percent:.1f}%\n• **Modo mantenimiento:** {'🟢 ACTIVO' if is_m else '🔴 DESACTIVADO'}"
    await MessageService().send_protected_message(message.chat.id, r)


async def queue_command(client, message):
    uid = message.from_user.id
    is_admin = settings.is_admin(uid)
    active = await active_compressions_repo.list_all()
    downloaded = await downloaded_videos_repo.list_sorted()
    pending = await pending_repo.list_sorted()
    progress = await app_state.all_progress()
    pm = {k: {"stage":v.stage, "percent":v.percent} for k,v in progress.items()}
    text = await format_queue_status(active, downloaded, pending, pm, uid, is_admin)
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔄 Actualizar", callback_data="refresh_queue"), InlineKeyboardButton("❌ Cerrar", callback_data="close_queue")]])
    await MessageService().send_protected_message(message.chat.id, text, reply_markup=kb)


async def show_queue_command(client, message):
    await queue_command(client, message)


async def cancel_command(client, message):
    uid = message.from_user.id
    cancelled = await app_state.cancel_user_tasks(uid, active_compressions_repo)
    if cancelled:
        await MessageService().send_protected_message(message.chat.id, f"✅ {len(cancelled)} compresión(es) cancelada(s).")
    else:
        await MessageService().send_protected_message(message.chat.id, "ℹ️ No tienes compresiones activas para cancelar.")


async def cancel_queue_command(client, message):
    uid = message.from_user.id
    pending = await pending_repo.list_sorted()
    up = [p for p in pending if p["user_id"] == uid]
    if not up:
        await MessageService().send_protected_message(message.chat.id, "ℹ️ No tienes videos en cola.")
        return
    for p in up: await pending_repo.remove(p["compression_id"])
    await MessageService().send_protected_message(message.chat.id, f"✅ {len(up)} video(s) eliminado(s) de tu cola.")


async def ayuda_handler(client, message):
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("👨🏻‍💻 Soporte", url=f"https://t.me/{settings.support_username}")]])
    await MessageService().send_protected_message(message.chat.id, MessageTemplates.help_message(), reply_markup=kb)
