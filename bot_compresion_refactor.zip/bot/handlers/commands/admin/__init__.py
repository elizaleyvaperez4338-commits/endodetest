"""Comandos de administrador."""
from __future__ import annotations
import asyncio, datetime as dt, io, json, os, tempfile, zipfile
from typing import Optional
import psutil
from bson.json_util import dumps
from pyrogram import Client
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
from bot.core.config import settings
from bot.core.logging import logger
from bot.core.state import app_state
from bot.db.client import db
from bot.db.repositories import active_compressions_repo, banned_repo, downloaded_videos_repo, pending_repo, temp_keys_repo, users_repo, user_settings_repo, payments_repo
from bot.services.maintenance_service import MaintenanceService
from bot.services.message_service import MessageService
from bot.services.plan_service import PlanService
from bot.services.stats_service import StatsService
from bot.services.broadcast_service import BroadcastService, BroadcastMessage
from bot.ui.keyboards import KeyboardFactory
from bot.ui.messages import MessageTemplates
from bot.utils.time_utils import now_cuba, sizeof_fmt
from bot.workers.watchdog import kill_orphan_ffmpeg, Watchdog


async def setdays_command(client, message):
    parts = message.text.split()
    if len(parts) != 2:
        await message.reply("⚠️ **Formato:** `/setdays <número_de_días>`\nEjemplo: `/setdays 2`")
        return
    try: days = int(parts[1])
    except ValueError:
        await message.reply("❌ El número de días debe ser un entero.")
        return
    if days <= 0:
        await message.reply("❌ **El número de días debe ser mayor a 0**")
        return
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("✅ Confirmar", callback_data=f"confirm_setdays_{days}"), InlineKeyboardButton("❌ Cancelar", callback_data="cancel_setdays")]])
    await message.reply(f"⚠️ **¿Estás seguro de que quieres agregar {days} día(s) a TODOS los usuarios?**\n\n• **Días a agregar**: {days}\n• **Se notificará** a todos los usuarios afectados\n• **Esta acción no se puede deshacer**", reply_markup=kb)


async def _apply_setdays(days, admin_id):
    updated, failed = await users_repo.add_days_to_all(days)
    users = await users_repo.list_with_plan(["standard","pro","premium"])
    for u in users:
        try:
            await MessageService().send_protected_message(u["user_id"], f"🎉 **¡Se han agregado {days} día(s) a tu plan!**\n\n¡Disfruta del tiempo adicional! 🎬")
            await asyncio.sleep(0.05)
        except Exception: pass
    return updated, failed


async def status_command(client, message):
    stats = await _get_system_stats()
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔄 Actualizar", callback_data="refresh_status_stats")]])
    await message.reply(stats, reply_markup=kb)


async def _get_system_stats():
    cpu = psutil.cpu_percent(interval=None)
    ram = psutil.virtual_memory()
    swap = psutil.swap_memory()
    disk = psutil.disk_usage("/")
    def bar(p, n=10):
        p = max(0, min(100, p)); f = int(n*p/100)
        return f"{'█'*f}{'▒'*(n-f)} {p:.1f}%"
    text = f"🖥️ **Estadísticas del Sistema en Tiempo Real**\n\n**CPU**  : {bar(cpu)}\n**RAM**  : {bar(ram.percent)}\n          {sizeof_fmt(ram.used)}/{sizeof_fmt(ram.total)}\n**SWAP** : {bar(swap.percent)}\n**DISK** : {bar(disk.percent)}\n          {sizeof_fmt(disk.used)}/{sizeof_fmt(disk.total)}\n\n"
    try:
        if hasattr(psutil, "sensors_temperatures"):
            temps = psutil.sensors_temperatures()
            if temps and "coretemp" in temps: text += f"🌡️ **Temperatura CPU**: {temps['coretemp'][0].current}°C\n"
    except Exception: pass
    return text


async def watchdog_status_command(client, message):
    stats = await StatsService().today()
    await message.reply(f"✅ **Watchdog funcionando correctamente**\n\n🔄 Reanudaciones automáticas (hoy): {stats.get('auto_recoveries', 0)}")


async def log_command(client, message):
    if not os.path.exists(settings.log_file):
        await message.reply("❌ No se encontró el archivo de log.")
        return
    size = os.path.getsize(settings.log_file)
    await message.reply_document(document=settings.log_file, file_name=f"bot_log_{now_cuba().strftime('%Y%m%d_%H%M%S')}.log", caption=f"📋 **Log del bot**\n📦 Tamaño: {sizeof_fmt(size)}")


async def backup_command(client, message):
    msg = await message.reply("🔄 **Creando backup de la base de datos...**")
    try:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for cn in ["active_compressions","banned_users","pending_confirmations","pending","temp_keys","user_settings","users","downloaded_videos","daily_stats","pending_payments"]:
                try:
                    docs = list(db[cn].find({}))
                    zf.writestr(f"{cn}.json", dumps(docs, indent=2, default=str))
                except Exception as e: logger.error(f"Error respaldando {cn}: {e}")
        buf.seek(0)
        ds = now_cuba().strftime("%Y-%m-%d_%H-%M-%S")
        await message.reply_document(document=buf, file_name=f"backup_{ds}.zip", caption=f"✅ **Backup completado**\n\n⏰ **Fecha:** {ds.replace('_',' ')}")
        try: await msg.delete()
        except Exception: pass
    except Exception as e:
        logger.exception(f"Error en backup: {e}")
        try: await msg.edit("❌ **Error al crear el backup**")
        except Exception: await message.reply("❌ **Error al crear el backup**")


async def getdb_command(client, message):
    try:
        users = await asyncio.to_thread(lambda: list(users_repo._col.find({})))
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, encoding="utf-8") as f:
            await asyncio.to_thread(json.dump, users, f, default=str, indent=4)
            f.flush()
            await message.reply_document(document=f.name, caption=f"📊 Copia de la base de datos de usuarios\n👤**Usuarios:** {len(users)}")
            os.unlink(f.name)
    except Exception as e:
        logger.exception(f"Error en getdb: {e}")
        await message.reply("❌ Error al exportar la base de datos")


async def restdb_command(client, message):
    await message.reply("🔄 **Modo restauración activado**\n\nEnvía el archivo JSON de la base de datos que deseas restaurar.")


async def banuser_command(client, message):
    parts = message.text.split()
    if len(parts) != 2:
        await message.reply("Formato: /banuser <user_id>")
        return
    try: tid = int(parts[1])
    except ValueError:
        await message.reply("user_id debe ser numérico.")
        return
    if settings.is_admin(tid):
        await message.reply("No puedes banear a un administrador.")
        return
    await users_repo._col.delete_one({"user_id": tid})
    await banned_repo.ban(tid)
    await app_state.ban_user(tid)
    await user_settings_repo._col.delete_one({"user_id": tid})
    await downloaded_videos_repo._col.delete_many({"user_id": tid})
    await message.reply(f"Usuario {tid} baneado y eliminado.")


async def desuser_command(client, message):
    parts = message.text.split()
    if len(parts) != 2:
        await message.reply("Formato: /desuser <user_id>")
        return
    tid = int(parts[1])
    await banned_repo.unban(tid)
    await app_state.unban_user(tid)
    await message.reply(f"Usuario {tid} desbaneado.")


async def deleteuser_command(client, message):
    await banuser_command(client, message)


async def viewban_command(client, message):
    banned = await banned_repo.all()
    if not banned:
        await message.reply("**No hay usuarios baneados.**")
        return
    r = "**Usuarios Baneados**\n\n"
    for i, b in enumerate(banned, 1):
        uid = b["user_id"]
        ba = b.get("banned_at", "¿?")
        if isinstance(ba, dt.datetime): ba = ba.strftime("%Y-%m-%d %H:%M:%S")
        r += f"{i}• 🆔 ID: `{uid}` ⏰ {ba}\n"
    await message.reply(r)


async def setplan_command(client, message):
    parts = message.text.split()
    if len(parts) != 3:
        await message.reply("Formato: /setplan <user_id> <plan>")
        return
    try: uid = int(parts[1])
    except ValueError:
        await message.reply("user_id debe ser numérico.")
        return
    plan = parts[2].lower()
    if plan not in settings.plan_durations:
        await message.reply(f"Plan inválido. Opciones: {', '.join(settings.plan_durations)}")
        return
    if await PlanService().set_plan(uid, plan):
        await message.reply(f"**Plan del usuario {uid} actualizado a {plan}.**")
    else:
        await message.reply("⚠️ **Error al actualizar el plan.**")


async def userinfo_command(client, message):
    parts = message.text.split()
    if len(parts) != 2:
        await message.reply("Formato: /userinfo <user_id>")
        return
    uid = int(parts[1])
    doc = await users_repo.get(uid)
    if not doc:
        await message.reply("⚠️ Usuario no registrado")
        return
    plan = (doc.get("plan") or "Ninguno").capitalize()
    jd = doc.get("join_date", "Desconocido")
    exp = doc.get("expires_at", "No expira")
    cv = doc.get("compressed_videos", 0)
    if isinstance(jd, dt.datetime): jd = jd.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(exp, dt.datetime): exp = exp.strftime("%Y-%m-%d %H:%M:%S")
    await message.reply(f"🆔 **ID**: `{uid}`\n📝 **Plan**: {plan}\n🎬 **Videos comprimidos**: {cv}\n📅 **Fecha de registro**: {jd}\n⏰ **Expira**: {exp}")


async def restuser_command(client, message):
    await users_repo._col.delete_many({})
    await message.reply("✅ **Todos los usuarios eliminados.**")


async def admin_stats_command(client, message):
    tu = await users_repo.count()
    ac = await active_compressions_repo.count()
    dl = await downloaded_videos_repo.count()
    pe = await pending_repo.count()
    ts = await StatsService().today()
    await message.reply(f"📊 **Estadísticas del bot**\n\n👥 **Usuarios totales:** {tu}\n🗜️ **Compresiones activas:** {ac}\n📥 **Videos descargados:** {dl}\n⏳ **Pendientes en cola:** {pe}\n\n📅 **Hoy:**\n• Descargados: {ts.get('videos_downloaded', 0)}\n• Comprimidos: {ts.get('videos_compressed', 0)}\n• Recuperaciones: {ts.get('auto_recoveries', 0)}")


async def list_users_command(client, message):
    users = await users_repo.all()
    if not users:
        await message.reply("No hay usuarios registrados.")
        return
    r = f"👥 **Usuarios registrados ({len(users)} total, mostrando primeros 50):**\n\n"
    for u in users[:50]:
        r += f"• 🆔 `{u['user_id']}` — {(u.get('plan') or 'ninguno').capitalize()}\n"
    await message.reply(r)


async def broadcast_command(client, message):
    if not message.text or len(message.text.split()) < 2:
        await message.reply("⚠️ Formato: /msg <mensaje>")
        return
    text = message.text.split(maxsplit=1)[1]
    if not text.strip():
        await message.reply("⚠️ El mensaje no puede estar vacío")
        return
    await BroadcastService().enqueue(BroadcastMessage(admin_id=message.from_user.id, text=text))
    await message.reply("📤 **Difusión iniciada!** Recibirás un reporte al completarse.")


async def broadcast_multimedia_command(client, message):
    await app_state.set_broadcast_session(message.from_user.id, {"type":"awaiting_content"})
    await message.reply("📢 **Modo difusión activado**\n\nEnvía el mensaje que deseas difundir a todos los usuarios con plan activo.\nPara cancelar, usa /cancelbroadcast")


async def cancel_broadcast_command(client, message):
    await app_state.del_broadcast_session(message.from_user.id)
    await message.reply("✅ **Difusión cancelada.**")


async def maintenance_on_command(client, message):
    m = MaintenanceService()
    if await m.is_active():
        await message.reply(MessageTemplates.MAINTENANCE_ALREADY_ON)
        return
    await m.activate()
    await message.reply(MessageTemplates.MAINTENANCE_ENABLED)


async def maintenance_off_command(client, message):
    m = MaintenanceService()
    if not await m.is_active():
        await message.reply(MessageTemplates.MAINTENANCE_ALREADY_OFF)
        return
    await m.deactivate()
    await message.reply(MessageTemplates.MAINTENANCE_DISABLED)


async def daily_stats_command(client, message):
    s = await StatsService().today()
    gb = s.get("bytes_downloaded", 0) / (1024**3)
    await message.reply(f"📊 **Actividad del Bot (HOY):**\n📅 **Fecha:** {now_cuba().strftime('%d/%m/%Y | %I:%M%p').lower()}\n\n📥 **Videos descargados:** {s.get('videos_downloaded', 0)}\n⬇️ **GB descargados:** {gb:.2f} GB\n🗜️ **Videos comprimidos:** {s.get('videos_compressed', 0)}\n🔄 **Reanudaciones automáticas:** {s.get('auto_recoveries', 0)}")


async def restart_command(client, message):
    msg = await message.reply("🔄 **Reiniciando bot...**")
    await asyncio.sleep(1)
    await active_compressions_repo.delete_many({})
    await downloaded_videos_repo.delete_many({})
    kill_orphan_ffmpeg()
    await msg.edit("**Bot reiniciado con éxito**\n\n✅ Todos los procesos activos cancelados\n✅ Cola de compresión vaciada\n✅ Videos descargados eliminados\n✅ Procesos FFmpeg terminados\n✅ Estado interno limpiado")


async def delete_all_pending(client, message):
    n1 = await pending_repo.delete_many({})
    n2 = await downloaded_videos_repo.delete_many({})
    await message.reply(f"**🗑️Cola eliminada.**\n**➥Se eliminaron {n1} elementos pendientes.**\n**➥Se eliminaron {n2} videos descargados.**")


async def delete_one_from_pending(client, message):
    import re
    match = re.match(r"^/del_(\d+)$", message.text.strip())
    if not match:
        await message.reply("⚠️ Formato inválido. Usa `/del_1`, `/del_2`, etc.")
        return
    idx = int(match.group(1)) - 1
    cola = await pending_repo.list_sorted()
    if idx < 0 or idx >= len(cola):
        await message.reply("⚠️ Número fuera de rango.")
        return
    e = cola[idx]
    await pending_repo.remove(e["compression_id"])
    await message.reply(f"✅ Eliminado de la cola:\n📁 {e.get('file_name', '¿?')}\n👤 ID: `{e['user_id']}`")


async def generate_key_command(client, message):
    parts = message.text.split()
    if len(parts) != 4:
        await message.reply(f"Formato: /generatekey <plan> <duration_value> <duration_unit>\nEjemplo: /generatekey premium 7 days\nPlanes válidos: {', '.join(settings.plan_durations)}\nUnidades: minutes, hours, days")
        return
    plan = parts[1].lower()
    if plan not in settings.plan_durations:
        await message.reply(f"Plan inválido. Opciones: {', '.join(settings.plan_durations)}")
        return
    try: dv = int(parts[2])
    except ValueError:
        await message.reply("duration_value debe ser numérico.")
        return
    du = parts[3].lower()
    if du not in ("minutes","hours","days"):
        await message.reply("Unidad inválida. Usa: minutes, hours, days")
        return
    import secrets, string
    key = "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(16))
    exp = now_cuba() + dt.timedelta(days=30)
    await temp_keys_repo.create(key, plan, dv, du, exp)
    await message.reply(f"✅ **Clave generada:**\n\n`{key}`\n\n• Plan: {plan.capitalize()}\n• Duración: {dv} {du}\n• Expira: {exp.strftime('%Y-%m-%d %H:%M')}")


async def list_keys_command(client, message):
    keys = await temp_keys_repo.list_unused()
    if not keys:
        await message.reply("No hay claves disponibles.")
        return
    r = f"🔑 **Claves disponibles ({len(keys)}):**\n\n"
    for k in keys[:50]:
        r += f"• `{k['key']}` — {k['plan'].capitalize()} ({k['duration_value']} {k['duration_unit']})\n"
    await message.reply(r)


async def del_keys_command(client, message):
    n = await temp_keys_repo.delete_all_unused()
    await message.reply(f"✅ {n} clave(s) eliminada(s).")


async def manual_check_expiry_command(client, message):
    from bot.workers.expiry_checker import ExpiryChecker
    checker = ExpiryChecker()
    e, n = await checker.check_expirations()
    await message.reply(f"✅ **Chequeo manual completado**\n\n• Planes expirados: {e}\n• Usuarios notificados: {n}")


async def startup_command(client, message):
    msg = await message.reply("🔄 Recuperando videos pendientes...")
    w = Watchdog()
    await w.recover_pending_compressions()
    await msg.edit("✅ Recuperación completada.")
