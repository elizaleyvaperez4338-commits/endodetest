"""Cliente MongoDB + índices. FIX A-9."""
from __future__ import annotations
from pymongo import MongoClient, ASCENDING
from pymongo.database import Database
from bot.core.config import settings


_client = MongoClient(settings.mongo_uri)
db: Database = _client[settings.database_name]


def get_collection(name): return db[name]


def ensure_indexes():
    """FIX A-9: índices faltantes."""
    db["pending"].create_index([("seq", ASCENDING)])
    db["pending"].create_index([("compression_id", ASCENDING)])
    db["pending"].create_index([("user_id", ASCENDING)])
    db["downloaded_videos"].create_index([("compression_id", ASCENDING)])
    db["downloaded_videos"].create_index([("timestamp", ASCENDING)])
    db["downloaded_videos"].create_index([("user_id", ASCENDING)])
    db["active_compressions"].create_index([("compression_id", ASCENDING)])
    db["active_compressions"].create_index([("user_id", ASCENDING)])
    db["users"].create_index([("user_id", ASCENDING)], unique=True)
    db["users"].create_index([("plan", ASCENDING)])
    db["temp_keys"].create_index([("key", ASCENDING)], unique=True)
    db["temp_keys"].create_index([("used", ASCENDING)])
    db["banned_users"].create_index([("user_id", ASCENDING)], unique=True)
    db["user_settings"].create_index([("user_id", ASCENDING)], unique=True)
    db["pending_payments"].create_index([("user_id", ASCENDING)])
    db["pending_payments"].create_index([("status", ASCENDING)])
    db["access_denied_log"].create_index([("user_id", ASCENDING)], unique=True)
    db["daily_stats"].create_index([("date", ASCENDING)], unique=True)
    # FIX M-1: upsert atómico
    db["counters"].update_one({"_id":"pending_seq"}, {"$setOnInsert":{"seq":0}}, upsert=True)
