"""Repositories. FIX M-4: async via asyncio.to_thread."""
from __future__ import annotations
import asyncio, datetime as dt
from typing import Any, Optional
from bson import ObjectId
from pymongo.collection import Collection
from pymongo.database import Database
from pymongo import ReturnDocument

from bot.db.client import db
from bot.models.compression import VideoSettings
from bot.models.payment import PaymentRequest, PaymentStatus


def _run(func, *args, **kwargs):
    return asyncio.to_thread(func, *args, **kwargs)


class BaseRepository:
    collection_name = ""
    def __init__(self, database=None):
        self._db = database or db
        self._col: Collection = self._db[self.collection_name]
    async def count(self, query=None): return await _run(self._col.count_documents, query or {})
    async def delete_many(self, query): r = await _run(self._col.delete_many, query); return r.deleted_count
    async def delete_one(self, query): r = await _run(self._col.delete_one, query); return r.deleted_count > 0


class CountersRepository(BaseRepository):
    collection_name = "counters"
    async def next_seq(self, name="pending_seq"):
        await _run(self._col.update_one, {"_id":name}, {"$setOnInsert":{"seq":0}}, upsert=True)
        result = await _run(self._col.find_one_and_update, {"_id":name}, {"$inc":{"seq":1}}, return_document=ReturnDocument.AFTER)
        if result is None:
            doc = await _run(self._col.find_one, {"_id":name})
            return doc["seq"] if doc else 0
        return result["seq"]


class UsersRepository(BaseRepository):
    collection_name = "users"
    async def get(self, user_id): return await _run(self._col.find_one, {"user_id":user_id})
    async def upsert(self, user_id, **fields):
        await _run(self._col.update_one, {"user_id":user_id}, {"$set":fields}, upsert=True)
    async def set_plan(self, user_id, plan, expires_at=None):
        update = {"$set":{"plan":plan}, "$setOnInsert":{"join_date":dt.datetime.now(dt.timezone.utc)}}
        if expires_at is not None: update["$set"]["expires_at"] = expires_at
        await _run(self._col.update_one, {"user_id":user_id}, update, upsert=True)
    async def increment_compressed(self, user_id):
        await _run(self._col.update_one, {"user_id":user_id}, {"$inc":{"compressed_videos":1}}, upsert=True)
    async def list_with_plan(self, plans):
        return await _run(lambda: list(self._col.find({"plan":{"$in":plans}, "expires_at":{"$exists":True}})))
    async def add_days_to_all(self, days):
        users = await self.list_with_plan(["standard","pro","premium"])
        updated=0; failed=0
        for u in users:
            uid=u["user_id"]; cur=u.get("expires_at")
            if not isinstance(cur, dt.datetime): failed+=1; continue
            tz=cur.tzinfo; new=cur+dt.timedelta(days=days)
            if tz: new=new.replace(tzinfo=tz)
            await self.upsert(uid, expires_at=new); updated+=1
        return updated, failed
    async def all(self): return await _run(lambda: list(self._col.find({})))


class PendingRepository(BaseRepository):
    collection_name = "pending"
    async def add(self, doc):
        seq = await CountersRepository(self._db).next_seq()
        doc["seq"] = seq
        await _run(self._col.insert_one, doc)
        return seq
    async def get(self, cid): return await _run(self._col.find_one, {"compression_id":cid})
    async def remove(self, cid): return await self.delete_one({"compression_id":cid})
    async def position_of(self, cid):
        doc = await self.get(cid)
        if not doc: return 0
        seq = doc["seq"]
        count = await _run(self._col.count_documents, {"seq":{"$lt":seq}})
        return count + 1
    async def list_sorted(self): return await _run(lambda: list(self._col.find().sort("seq",1)))
    async def count_for_user(self, uid): return await _run(self._col.count_documents, {"user_id":uid})


class DownloadedVideosRepository(BaseRepository):
    collection_name = "downloaded_videos"
    async def add(self, doc): await _run(self._col.insert_one, doc)
    async def get(self, cid): return await _run(self._col.find_one, {"compression_id":cid})
    async def remove(self, cid): return await self.delete_one({"compression_id":cid})
    async def list_sorted(self): return await _run(lambda: list(self._col.find().sort("timestamp",1)))
    async def count_for_user(self, uid): return await _run(self._col.count_documents, {"user_id":uid})
    async def update_wait_msg(self, cid, mid):
        await _run(self._col.update_one, {"compression_id":cid}, {"$set":{"wait_msg_id":mid}})


class ActiveCompressionsRepository(BaseRepository):
    collection_name = "active_compressions"
    async def add(self, doc): await _run(self._col.insert_one, doc)
    async def get_one(self): return await _run(self._col.find_one, {})
    async def get_by_compression(self, cid): return await _run(self._col.find_one, {"compression_id":cid})
    async def remove(self, cid): return await self.delete_one({"compression_id":cid})
    async def list_all(self): return await _run(lambda: list(self._col.find({})))


class PaymentsRepository(BaseRepository):
    collection_name = "pending_payments"
    async def create(self, user_id, plan, method):
        doc = {"user_id":user_id,"plan":plan,"method":method,"status":"waiting_receipt","created_at":dt.datetime.now(dt.timezone.utc)}
        r = await _run(self._col.insert_one, doc); return r.inserted_id
    async def get(self, pid): return await _run(self._col.find_one, {"_id":pid})
    async def find_waiting_receipt(self, uid): return await _run(self._col.find_one, {"user_id":uid,"status":"waiting_receipt"})
    async def update_status(self, pid, status, file_id=None, instruction_msg_id=None, confirmation_msg_id=None):
        update = {"$set":{"status":status}}
        if file_id is not None: update["$set"]["file_id"]=file_id
        if instruction_msg_id is not None: update["$set"]["instruction_msg_id"]=instruction_msg_id
        if confirmation_msg_id is not None: update["$set"]["confirmation_msg_id"]=confirmation_msg_id
        await _run(self._col.update_one, {"_id":pid}, update)
    async def delete(self, pid): await _run(self._col.delete_one, {"_id":pid})
    async def delete_user_pending(self, uid):
        await _run(self._col.delete_many, {"user_id":uid,"status":{"$in":["awaiting_capture","waiting_receipt"]}})


class TempKeysRepository(BaseRepository):
    collection_name = "temp_keys"
    async def create(self, key, plan, dv, du, expires_at):
        await _run(self._col.insert_one, {"key":key,"plan":plan,"duration_value":dv,"duration_unit":du,"expires_at":expires_at,"used":False,"created_at":dt.datetime.now(dt.timezone.utc)})
    async def find_valid(self, key): return await _run(self._col.find_one, {"key":key,"used":False})
    async def mark_used(self, kid): await _run(self._col.update_one, {"_id":kid}, {"$set":{"used":True}})
    async def list_unused(self): return await _run(lambda: list(self._col.find({"used":False})))
    async def delete_all_unused(self): return await self.delete_many({"used":False})


class BannedRepository(BaseRepository):
    collection_name = "banned_users"
    async def ban(self, uid):
        await _run(self._col.update_one, {"user_id":uid}, {"$set":{"user_id":uid,"banned_at":dt.datetime.now(dt.timezone.utc)}}, upsert=True)
    async def unban(self, uid): return await self.delete_one({"user_id":uid})
    async def all(self): return await _run(lambda: list(self._col.find({})))


class UserSettingsRepository(BaseRepository):
    collection_name = "user_settings"
    async def get_video_settings(self, uid):
        doc = await _run(self._col.find_one, {"user_id":uid})
        if doc and "video_settings" in doc: return VideoSettings.from_dict(doc["video_settings"])
        return VideoSettings()
    async def set_video_settings(self, uid, settings):
        await _run(self._col.update_one, {"user_id":uid}, {"$set":{"video_settings":settings.to_dict()}}, upsert=True)
    async def update_video_settings(self, uid, command):
        try: new = VideoSettings.parse_command(command)
        except ValueError: return False
        await self.set_video_settings(uid, new); return True
    async def reset_video_settings(self, uid): await self.delete_one({"user_id":uid})
    async def get_compression_mode(self, uid):
        doc = await _run(self._col.find_one, {"user_id":uid})
        if doc and "compression_mode" in doc: return doc["compression_mode"]
        return "before"
    async def set_compression_mode(self, uid, mode):
        await _run(self._col.update_one, {"user_id":uid}, {"$set":{"compression_mode":mode}}, upsert=True)


class DailyStatsRepository(BaseRepository):
    collection_name = "daily_stats"
    async def _today_str(self):
        import zoneinfo
        from bot.core.config import settings as _s
        return dt.datetime.now(zoneinfo.ZoneInfo(_s.timezone)).strftime("%Y-%m-%d")
    async def get_today(self):
        ds = await self._today_str()
        doc = await _run(self._col.find_one, {"date":ds})
        if not doc: return {"videos_downloaded":0,"bytes_downloaded":0,"videos_compressed":0,"auto_recoveries":0}
        return doc
    async def inc_download(self, fs):
        ds = await self._today_str()
        await _run(self._col.update_one, {"date":ds}, {"$inc":{"videos_downloaded":1,"bytes_downloaded":fs}}, upsert=True)
    async def inc_compressed(self):
        ds = await self._today_str()
        await _run(self._col.update_one, {"date":ds}, {"$inc":{"videos_compressed":1}}, upsert=True)
    async def inc_recovery(self, n=1):
        ds = await self._today_str()
        await _run(self._col.update_one, {"date":ds}, {"$inc":{"auto_recoveries":n}}, upsert=True)


class AccessDeniedLogRepository(BaseRepository):
    collection_name = "access_denied_log"
    async def can_notify(self, uid, cooldown=300):
        now = dt.datetime.now(dt.timezone.utc)
        doc = await _run(self._col.find_one, {"user_id":uid})
        if doc and doc.get("last_notification"):
            last = doc["last_notification"]
            if last.tzinfo is None: last = last.replace(tzinfo=dt.timezone.utc)
            if (now-last).total_seconds() < cooldown: return False
        await _run(self._col.update_one, {"user_id":uid}, {"$set":{"last_notification":now}}, upsert=True)
        return True


class PendingConfirmationsRepository(BaseRepository):
    collection_name = "pending_confirmations"
    async def create(self, doc):
        r = await _run(self._col.insert_one, doc); return r.inserted_id
    async def get(self, pid): return await _run(self._col.find_one, {"_id":pid})
    async def delete(self, pid): return await self.delete_one({"_id":pid})


# Singletons
users_repo = UsersRepository()
pending_repo = PendingRepository()
downloaded_videos_repo = DownloadedVideosRepository()
active_compressions_repo = ActiveCompressionsRepository()
payments_repo = PaymentsRepository()
temp_keys_repo = TempKeysRepository()
banned_repo = BannedRepository()
user_settings_repo = UserSettingsRepository()
daily_stats_repo = DailyStatsRepository()
counters_repo = CountersRepository()
access_denied_log_repo = AccessDeniedLogRepository()
pending_confirmations_repo = PendingConfirmationsRepository()
