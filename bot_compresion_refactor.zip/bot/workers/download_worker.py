"""Worker de descarga."""
from __future__ import annotations
import asyncio
from typing import Optional
from bot.core.logging import logger
from bot.core.state import app_state
from bot.db.repositories import pending_repo
from bot.services.download_service import DownloadService


class DownloadWorker:
    def __init__(self, service=None):
        self._service = service or DownloadService()
        self._queue: asyncio.PriorityQueue = asyncio.PriorityQueue()

    async def enqueue(self, seq, *args): await self._queue.put((seq, *args))

    async def run(self):
        logger.info("Worker de descarga iniciado")
        while True:
            try:
                item = await self._queue.get()
                _, cid, uid, chat_id, msg_id, file_obj, file_name, wait_msg, caption, custom = item
                pending = await pending_repo.get(cid)
                if not pending:
                    if wait_msg:
                        try: await wait_msg.delete()
                        except Exception: pass
                    continue
                await self._service.download(cid, uid, chat_id, msg_id, file_obj, file_name, wait_msg, caption, custom)
            except asyncio.CancelledError: break
            except Exception as e:
                logger.exception(f"Error en download worker: {e}")
                await asyncio.sleep(1)
            finally:
                try: self._queue.task_done()
                except ValueError: pass


_download_worker: Optional[DownloadWorker] = None


async def start_download_worker():
    global _download_worker
    if _download_worker is None: _download_worker = DownloadWorker()
    current = await app_state.get_download_worker_task()
    if current is None or current.done():
        task = asyncio.create_task(_download_worker.run())
        await app_state.set_download_worker_task(task)
        logger.info("Worker de descarga (re)iniciado")


async def watchdog_download_worker(interval=30):
    while True:
        await asyncio.sleep(interval)
        try:
            current = await app_state.get_download_worker_task()
            if current is None or current.done():
                logger.warning("Watchdog: download worker muerto, reiniciando")
                await start_download_worker()
        except asyncio.CancelledError: break
        except Exception as e: logger.exception(f"Error en watchdog_download_worker: {e}")
