"""Watchdog. FIX A-7: kill_orphan_ffmpeg."""
from __future__ import annotations
import asyncio, datetime as dt
from typing import Optional
import psutil
from bot.core.logging import logger
from bot.core.state import app_state
from bot.db.repositories import active_compressions_repo, downloaded_videos_repo
from bot.services.stats_service import StatsService


def kill_orphan_ffmpeg():
    killed = 0
    for proc in psutil.process_iter(["pid","name"]):
        try:
            if proc.info["name"] and "ffmpeg" in proc.info["name"].lower():
                proc.terminate(); killed += 1
                logger.info(f"FFmpeg huérfano terminado: PID {proc.info['pid']}")
        except (psutil.NoSuchProcess, psutil.AccessDenied): continue
    return killed


class Watchdog:
    def __init__(self, interval=60):
        self._interval = interval
        self._last_run = None
        self._stats = StatsService()

    async def run_forever(self):
        while True:
            try:
                if self._last_run is not None: await asyncio.sleep(self._interval)
                await self.recover_pending_compressions()
                self._last_run = dt.datetime.now(dt.timezone.utc)
            except asyncio.CancelledError: break
            except Exception as e:
                logger.exception(f"Error en watchdog: {e}")
                await asyncio.sleep(60)

    async def recover_pending_compressions(self):
        dc = await downloaded_videos_repo.count()
        if dc == 0: return
        ac = await active_compressions_repo.count()
        if ac > 0: return
        logger.info("Watchdog: recuperando compresiones perdidas")
        downloaded = await downloaded_videos_repo.list_sorted()
        from bot.workers.compression_worker import CompressionWorkerPool
        from bot.models.compression import CompressionTask
        from bot.core.app import app
        for v in downloaded:
            try:
                task = CompressionTask(compression_id=v["compression_id"], user_id=v["user_id"], original_video_path=v["file_path"], file_name=v["file_name"], chat_id=v.get("chat_id", v["user_id"]), original_message_id=v.get("original_message_id",0), wait_msg_id=v.get("wait_msg_id",0), caption=v.get("original_caption"), custom_settings=v.get("custom_settings"))
                if task.wait_msg_id:
                    try: task.wait_msg = await app.get_messages(task.chat_id, task.wait_msg_id)
                    except Exception as e: logger.warning(f"No se pudo recuperar wait_msg: {e}")
                await _global_pool().enqueue(task)
            except Exception as e: logger.error(f"Error recuperando video: {e}")
        await self._stats.record_recovery(1)

    @property
    def last_run(self): return self._last_run


_pool_instance: Optional[CompressionWorkerPool] = None


def _global_pool():
    global _pool_instance
    if _pool_instance is None:
        from bot.core.config import settings
        _pool_instance = CompressionWorkerPool(n_workers=settings.compression_workers)
    return _pool_instance


def set_global_pool(pool):
    global _pool_instance
    _pool_instance = pool
