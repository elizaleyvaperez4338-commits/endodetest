"""Loop de expiración de planes."""
from __future__ import annotations
import asyncio, datetime as dt
from typing import Optional
from bot.core.logging import logger
from bot.db.repositories import users_repo
from bot.services.message_service import MessageService


class ExpiryChecker:
    INTERVAL = 3600

    def __init__(self, interval=None):
        self._interval = interval or self.INTERVAL
        self._messages = MessageService()

    async def run_forever(self):
        while True:
            try:
                await asyncio.sleep(self._interval)
                await self.check_expirations()
            except asyncio.CancelledError: break
            except Exception as e:
                logger.exception(f"Error en ExpiryChecker: {e}")
                await asyncio.sleep(60)

    async def check_expirations(self):
        now = dt.datetime.now(dt.timezone.utc)
        expired=0; notified=0
        users = await users_repo.list_with_plan(["standard","pro","premium"])
        for u in users:
            exp = u.get("expires_at")
            if not exp: continue
            if exp.tzinfo is None: exp = exp.replace(tzinfo=dt.timezone.utc)
            if exp < now:
                await users_repo.upsert(u["user_id"], plan=None)
                expired += 1
                try:
                    await self._messages.send_protected_message(u["user_id"], "⚠️ **Tu plan ha expirado**\n\nUsa /planes para renovar tu acceso.")
                    notified += 1
                except Exception as e: logger.warning(f"No se pudo notificar a {u['user_id']}: {e}")
        if expired: logger.info(f"ExpiryChecker: {expired} expirados, {notified} notificados")
        return expired, notified
