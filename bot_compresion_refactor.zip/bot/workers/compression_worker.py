"""Worker pool de compresión. FIX C-1, M-22."""
from __future__ import annotations
import asyncio
from typing import Optional
from bot.core.logging import logger
from bot.core.state import app_state
from bot.db.repositories import downloaded_videos_repo
from bot.models.compression import CompressionTask
from bot.services.compression_service import CompressionService


class CompressionWorkerPool:
    def __init__(self, n_workers, service=None):
        self._n = n_workers
        self._service = service or CompressionService()
        self._queue: asyncio.Queue = asyncio.Queue()
        self._workers = []

    async def enqueue(self, task): await self._queue.put(task)

    async def start(self):
        for i in range(self._n):
            t = asyncio.create_task(self._run(i))
            self._workers.append(t)
            app_state.register_processing_task(t)
        logger.info(f"Iniciados {self._n} workers de compresión")

    async def _run(self, idx):
        while True:
            try:
                task = await self._queue.get()
                video = await downloaded_videos_repo.get(task.compression_id)
                if not video: continue
                try: await self._service.compress(task)
                except asyncio.CancelledError: raise
                except Exception as e: logger.exception(f"Worker {idx} falló: {e}")
            except asyncio.CancelledError: break
            finally:
                try: self._queue.task_done()
                except ValueError: pass

    async def stop(self):
        for w in self._workers: w.cancel()
        await asyncio.gather(*self._workers, return_exceptions=True)
        self._workers.clear()
