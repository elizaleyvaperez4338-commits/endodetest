"""Envío periódico de log."""
from __future__ import annotations
import asyncio, os
from typing import Optional
from bot.core.app import app
from bot.core.config import settings
from bot.core.logging import logger
from bot.utils.time_utils import sizeof_fmt, now_cuba


class LogSender:
    def __init__(self, interval=None):
        self._interval = interval or settings.log_send_interval

    async def run_forever(self):
        while True:
            try:
                await asyncio.sleep(self._interval)
                await self._send_log()
            except asyncio.CancelledError: break
            except Exception as e:
                logger.exception(f"Error en LogSender: {e}")
                await asyncio.sleep(60)

    async def _send_log(self):
        if not os.path.exists(settings.log_file): return
        size = os.path.getsize(settings.log_file)
        if size == 0: return
        ts = now_cuba().strftime("%Y%m%d_%H%M%S")
        try:
            await app.send_document(chat_id=settings.notification_group_id, document=settings.log_file, file_name=f"bot_log_{ts}.log", caption=f"📋 **Log del bot (envío periódico)**\n📦 Tamaño: {sizeof_fmt(size)}")
            logger.info("Log periódico enviado al grupo")
        except Exception as e: logger.error(f"Error enviando log: {e}")
