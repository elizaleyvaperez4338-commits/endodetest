"""Bot de compresión de videos para Telegram."""
__version__ = "32.0.0"
