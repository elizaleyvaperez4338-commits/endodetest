"""Estado centralizado. FIX C-3: 21 globales → AppState con locks."""
from __future__ import annotations
import asyncio, time
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Optional


@dataclass
class TaskInfo:
    type: str
    task: Optional[asyncio.Task] = None
    process: Optional[Any] = None
    original_message_id: Optional[int] = None
    progress_message_id: Optional[int] = None


@dataclass
class CompressionProgress:
    stage: str = ""
    current: float = 0
    total: float = 0
    percent: float = 0
    file_name: str = ""
    last_update: float = field(default_factory=time.time)


class AppState:
    def __init__(self):
        self._cancel_tasks = {}
        self._ffmpeg_procs = {}
        self._active_messages = {}
        self._compression_progress = {}
        self._temp_video_configs = {}
        self._temp_custom_settings = {}
        self._broadcast_sessions = {}
        self._sent_messages = {}
        self._last_progress_update = {}
        self._maintenance_mode = False
        self._ban_users = set()
        self._background_tasks = set()
        self._processing_tasks = []
        self._download_worker_task = None
        self._lock_cancel = asyncio.Lock()
        self._lock_progress = asyncio.Lock()
        self._lock_messages = asyncio.Lock()
        self._lock_broadcast = asyncio.Lock()
        self._lock_ban = asyncio.Lock()
        self._lock_maintenance = asyncio.Lock()
        self._lock_bg = asyncio.Lock()

    async def register_cancelable(self, cid, task_type, task=None, process=None, original_message_id=None, progress_message_id=None):
        async with self._lock_cancel:
            self._cancel_tasks[cid] = TaskInfo(type=task_type, task=task, process=process, original_message_id=original_message_id, progress_message_id=progress_message_id)

    async def unregister_cancelable(self, cid):
        async with self._lock_cancel:
            self._cancel_tasks.pop(cid, None)

    async def is_cancelled(self, cid):
        async with self._lock_cancel:
            return cid not in self._cancel_tasks

    async def get_cancelable(self, cid):
        async with self._lock_cancel:
            return self._cancel_tasks.get(cid)

    async def cancel_task(self, cid):
        async with self._lock_cancel:
            info = self._cancel_tasks.get(cid)
            if not info: return False
            try:
                if info.type == "download" and info.task and not info.task.done():
                    info.task.cancel()
                elif info.type == "ffmpeg" and info.process:
                    try: info.process.terminate()
                    except ProcessLookupError: pass
                return True
            except Exception:
                return False

    async def cancel_user_tasks(self, user_id, active_compressions_col):
        cancelled = []
        async with self._lock_cancel:
            for cid in list(self._cancel_tasks.keys()):
                doc = await active_compressions_col.find_one({"compression_id": cid})
                if doc and doc.get("user_id") == user_id:
                    info = self._cancel_tasks[cid]
                    if info.type == "download" and info.task and not info.task.done():
                        info.task.cancel()
                    elif info.type == "ffmpeg" and info.process:
                        try: info.process.terminate()
                        except ProcessLookupError: pass
                    cancelled.append(cid)
        return cancelled

    async def register_ffmpeg(self, cid, process):
        async with self._lock_cancel:
            self._ffmpeg_procs[cid] = process

    async def unregister_ffmpeg(self, cid):
        async with self._lock_cancel:
            self._ffmpeg_procs.pop(cid, None)

    async def set_active_message(self, cid, mid):
        async with self._lock_messages:
            self._active_messages[cid] = mid

    async def get_active_message(self, cid):
        async with self._lock_messages:
            return self._active_messages.get(cid)

    async def remove_active_message(self, cid):
        async with self._lock_messages:
            self._active_messages.pop(cid, None)

    async def update_progress(self, cid, stage, current=0, total=0, percent=0, file_name=""):
        async with self._lock_progress:
            self._compression_progress[cid] = CompressionProgress(stage=stage, current=current, total=total, percent=percent, file_name=file_name)

    async def get_progress(self, cid):
        async with self._lock_progress:
            return self._compression_progress.get(cid)

    async def remove_progress(self, cid):
        async with self._lock_progress:
            self._compression_progress.pop(cid, None)

    async def all_progress(self):
        async with self._lock_progress:
            return dict(self._compression_progress)

    def get_temp_config(self, key): return self._temp_video_configs.get(key, {})
    def set_temp_config(self, key, value): self._temp_video_configs[key] = value
    def del_temp_config(self, key): self._temp_video_configs.pop(key, None)
    def get_temp_custom_settings(self, uid): return self._temp_custom_settings.get(uid, {})
    def set_temp_custom_settings(self, uid, value): self._temp_custom_settings[uid] = value
    def del_temp_custom_settings(self, uid): self._temp_custom_settings.pop(uid, None)

    async def set_broadcast_session(self, aid, data):
        async with self._lock_broadcast: self._broadcast_sessions[aid] = data
    async def get_broadcast_session(self, aid):
        async with self._lock_broadcast: return self._broadcast_sessions.get(aid)
    async def del_broadcast_session(self, aid):
        async with self._lock_broadcast: self._broadcast_sessions.pop(aid, None)

    def track_sent(self, mid, data): self._sent_messages[mid] = data
    def get_sent(self, mid): return self._sent_messages.get(mid)

    def should_throttle(self, key, min_interval=1.5):
        now = time.time()
        last = self._last_progress_update.get(key, 0)
        if now - last < min_interval: return True
        self._last_progress_update[key] = now
        return False

    async def get_maintenance(self):
        async with self._lock_maintenance: return self._maintenance_mode
    async def set_maintenance(self, value):
        async with self._lock_maintenance: self._maintenance_mode = value

    async def is_banned(self, uid):
        async with self._lock_ban: return uid in self._ban_users
    async def ban_user(self, uid):
        async with self._lock_ban: self._ban_users.add(uid)
    async def unban_user(self, uid):
        async with self._lock_ban: self._ban_users.discard(uid)
    async def load_banned(self, uids):
        async with self._lock_ban: self._ban_users = set(uids)

    def spawn_background(self, coro):
        task = asyncio.create_task(coro)
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)
        return task

    def register_processing_task(self, task): self._processing_tasks.append(task)
    def get_processing_tasks(self): return list(self._processing_tasks)
    async def set_processing_tasks(self, tasks):
        async with self._lock_bg: self._processing_tasks = tasks
    async def get_download_worker_task(self):
        async with self._lock_bg: return self._download_worker_task
    async def set_download_worker_task(self, task):
        async with self._lock_bg: self._download_worker_task = task

    @asynccontextmanager
    async def track_compression(self, cid):
        try: yield
        finally:
            await self.unregister_cancelable(cid)
            await self.unregister_ffmpeg(cid)
            await self.remove_progress(cid)
            await self.remove_active_message(cid)


app_state: AppState = AppState()
