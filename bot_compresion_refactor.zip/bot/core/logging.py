"""Logging centralizado. FIX M-11: sin emojis."""
from __future__ import annotations
import logging, logging.handlers, sys
from pathlib import Path
from bot.core.config import settings


def setup_logging():
    log_path = Path(settings.log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    if root.handlers:
        return logging.getLogger("bot")
    root.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    fh = logging.handlers.TimedRotatingFileHandler(settings.log_file, when="H", interval=3, backupCount=10, encoding="utf-8")
    fh.setFormatter(fmt); root.addHandler(fh)
    sh = logging.StreamHandler(sys.stdout); sh.setFormatter(fmt); root.addHandler(sh)
    return logging.getLogger("bot")


logger = setup_logging()
