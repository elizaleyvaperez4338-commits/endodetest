"""Cliente Pyrogram singleton."""
from __future__ import annotations
from pyrogram import Client
from bot.core.config import settings

app: Client = Client(settings.session_name, api_id=settings.api_id, api_hash=settings.api_hash, bot_token=settings.bot_token)
