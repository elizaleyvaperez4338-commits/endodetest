"""Configuración centralizada. FIX A-5, A-17, A-19, M-17."""
from __future__ import annotations
import os
from dataclasses import dataclass, field
from typing import Final


def _env(name, default): return os.getenv(name, default) or default
def _env_int(name, default):
    try: return int(os.getenv(name, default))
    except (TypeError, ValueError): return default
def _env_bool(name, default=False):
    val = os.getenv(name, "").lower()
    return val in ("1","true","yes","on","si","sí") if val else default


@dataclass(frozen=True)
class Settings:
    api_id: int = _env_int("API_ID", 0)
    api_hash: str = _env("API_HASH", "")
    bot_token: str = _env("BOT_TOKEN", "")
    session_name: str = _env("SESSION_NAME", "compress_bot")
    mongo_uri: str = _env("MONGO_URI", "mongodb://localhost:27017")
    database_name: str = _env("DATABASE_NAME", "compress_bot")
    admins_ids: tuple = field(default_factory=lambda: tuple(int(x) for x in os.getenv("ADMINS_IDS","0").split(",") if x.strip().isdigit()))
    compression_workers: int = _env_int("COMPRESSION_WORKERS", 1)
    download_workers: int = _env_int("DOWNLOAD_WORKERS", 1)
    max_file_size_mb: int = _env_int("MAX_FILE_SIZE_MB", 2048)
    pro_queue_limit: int = _env_int("PRO_QUEUE_LIMIT", 2)
    premium_queue_limit: int = _env_int("PREMIUM_QUEUE_LIMIT", 4)
    ultra_queue_limit: int = _env_int("ULTRA_QUEUE_LIMIT", 10)
    watchdog_interval: int = _env_int("WATCHDOG_INTERVAL", 60)
    watchdog_download_interval: int = _env_int("WATCHDOG_DOWNLOAD_INTERVAL", 30)
    log_send_interval: int = _env_int("LOG_SEND_INTERVAL", 3600)
    bot_username: str = _env("BOT_USERNAME", "CompressFastBot")
    watermark_text: str = _env("WATERMARK_TEXT", "@CompressFastBot")
    watermark_font_path: str = _env("WATERMARK_FONT_PATH", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
    support_username: str = _env("SUPPORT_USERNAME", "VirtualMix_Shop")
    notification_group_id: int = _env_int("NOTIFICATION_GROUP_ID", -1003896005361)
    version: str = "32.0.0"
    timezone: str = _env("BOT_TIMEZONE", "America/Havana")
    key_rate_limit_per_min: int = _env_int("KEY_RATE_LIMIT_PER_MIN", 5)
    ffmpeg_binary: str = _env("FFMPEG_BINARY", "ffmpeg")
    ffprobe_binary: str = _env("FFPROBE_BINARY", "ffprobe")
    temp_dir: str = _env("BOT_TEMP_DIR", os.path.join(os.getcwd(), "bot_temp"))
    log_file: str = _env("BOT_LOG_FILE", "bot.log")
    bot_is_public: bool = _env_bool("BOT_IS_PUBLIC", False)
    plan_durations: dict = field(default_factory=lambda: {"standard":"7 días","pro":"15 días","premium":"30 días","ultra":"Ilimitado"})
    DEFAULT_VIDEO_SETTINGS: dict = field(default_factory=lambda: {"resolution":"-2:480","crf":"28","audio_bitrate":"64k","fps":"23","preset":"veryfast","codec":"libx264"})
    CUSTOM_RESOLUTION_OPTIONS: list = field(default_factory=lambda: ["640x360","-2:480","-2:720"])
    CUSTOM_CRF_OPTIONS: list = field(default_factory=lambda: ["25","28","30","32","35","38","40"])
    CUSTOM_FPS_OPTIONS: list = field(default_factory=lambda: ["20","22","25","28","30","35"])
    CUSTOM_AUDIO_OPTIONS: list = field(default_factory=lambda: ["64k","90k","128k"])
    SUPPORTED_VIDEO_EXTENSIONS: list = field(default_factory=lambda: ["mp4","mkv","avi","ts","mov","flv","wmv","webm","m4v","3gp","mpeg","mpg","3g2","rm","rmvb","vob","f4v","ogv","drc","nsv","mpe","m2v"])

    def queue_limit_for_plan(self, plan):
        if plan == "ultra": return self.ultra_queue_limit
        if plan == "premium": return self.premium_queue_limit
        if plan == "pro": return self.pro_queue_limit
        return 1

    def is_admin(self, user_id): return user_id in self.admins_ids


settings: Final[Settings] = Settings()
