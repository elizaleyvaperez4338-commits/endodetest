"""Entrypoint del bot."""
from __future__ import annotations
import asyncio
from bot.core.app import app
from bot.core.config import settings
from bot.core.logging import logger
from bot.core.state import app_state
from bot.db.client import ensure_indexes
from bot.db.repositories import banned_repo
from bot.handlers import register_all_handlers
from bot.workers.compression_worker import CompressionWorkerPool
from bot.workers.download_worker import start_download_worker, watchdog_download_worker
from bot.workers.watchdog import Watchdog, kill_orphan_ffmpeg
from bot.workers.log_sender import LogSender
from bot.workers.expiry_checker import ExpiryChecker
from bot.workers import watchdog as watchdog_module


async def _bootstrap():
    logger.info("=" * 60)
    logger.info(f"Iniciando bot v{settings.version}")
    logger.info("=" * 60)
    killed = kill_orphan_ffmpeg()
    if killed: logger.info(f"{killed} proceso(s) FFmpeg huérfano(s) terminado(s)")
    ensure_indexes()
    banned_docs = await banned_repo.all()
    await app_state.load_banned([d["user_id"] for d in banned_docs])
    logger.info(f"{len(banned_docs)} usuarios baneados cargados")
    pool = CompressionWorkerPool(n_workers=settings.compression_workers)
    await pool.start()
    watchdog_module.set_global_pool(pool)
    await start_download_worker()
    app_state.spawn_background(watchdog_download_worker(settings.watchdog_download_interval))
    watchdog = Watchdog(interval=settings.watchdog_interval)
    app_state.spawn_background(watchdog.run_forever())
    app_state.spawn_background(LogSender().run_forever())
    app_state.spawn_background(ExpiryChecker().run_forever())
    register_all_handlers(app)
    logger.info("Bot listo para recibir mensajes")


async def main():
    await _bootstrap()
    await app.start()
    bot_info = await app.get_me()
    logger.info(f"Bot iniciado: @{bot_info.username}")
    await asyncio.Event().wait()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot detenido por el usuario")
    except Exception as e:
        logger.critical(f"Error fatal al iniciar el bot: {e}", exc_info=True)
        import time; time.sleep(5)
