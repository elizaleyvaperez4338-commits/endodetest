"""Modelo de usuario y planes."""
from __future__ import annotations
import datetime as dt
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class PlanType(str, Enum):
    NONE = "none"; STANDARD = "standard"; PRO = "pro"; PREMIUM = "premium"; ULTRA = "ultra"


PLAN_DURATIONS = {"standard":"7 días","pro":"15 días","premium":"30 días","ultra":"Ilimitado"}


@dataclass
class User:
    user_id: int
    plan: Optional[str] = None
    join_date: Optional[dt.datetime] = None
    expires_at: Optional[dt.datetime] = None
    compressed_videos: int = 0
    username: Optional[str] = None
    first_name: Optional[str] = None

    @property
    def is_active(self):
        if self.plan is None: return False
        if self.expires_at is None: return True
        now = dt.datetime.now(self.expires_at.tzinfo) if self.expires_at.tzinfo else dt.datetime.now()
        return self.expires_at > now

    @classmethod
    def from_doc(cls, doc):
        return cls(user_id=doc["user_id"], plan=doc.get("plan"), join_date=doc.get("join_date"), expires_at=doc.get("expires_at"), compressed_videos=doc.get("compressed_videos",0), username=doc.get("username"), first_name=doc.get("first_name"))
