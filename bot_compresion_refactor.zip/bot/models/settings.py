from __future__ import annotations
from enum import Enum


class CompressionMode(str, Enum):
    BEFORE = "before"
    AFTER = "after"
