"""Modelo de pagos."""
from __future__ import annotations
import datetime as dt
from dataclasses import dataclass
from enum import Enum
from typing import Optional
from bson import ObjectId


class PaymentStatus(str, Enum):
    AWAITING_CAPTURE="awaiting_capture"; AWAITING_METHOD="awaiting_method"; WAITING_RECEIPT="waiting_receipt"; PENDING_ADMIN="pending_admin"; ACCEPTED="accepted"; REJECTED="rejected"


class PaymentMethod(str, Enum):
    USDT="usdt"; MTRANSFER="mtransfer"; SALDO="saldo"


@dataclass
class PaymentRequest:
    user_id: int
    plan: str
    method: Optional[str] = None
    status: PaymentStatus = PaymentStatus.AWAITING_METHOD
    file_id: Optional[str] = None
    instruction_msg_id: Optional[int] = None
    confirmation_msg_id: Optional[int] = None
    created_at: dt.datetime = None
    _id: Optional[ObjectId] = None

    @classmethod
    def from_doc(cls, doc):
        return cls(user_id=doc["user_id"], plan=doc["plan"], method=doc.get("method"), status=PaymentStatus(doc.get("status","awaiting_method")), file_id=doc.get("file_id"), instruction_msg_id=doc.get("instruction_msg_id"), confirmation_msg_id=doc.get("confirmation_msg_id"), created_at=doc.get("created_at"), _id=doc.get("_id"))
