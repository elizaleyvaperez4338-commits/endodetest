"""Modelo de compresión. FIX A-8: ID corto (8 hex)."""
from __future__ import annotations
import datetime as dt
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from bot.core.config import settings


class CompressionStatus(str, Enum):
    PENDING="pending"; DOWNLOADING="downloading"; DOWNLOADED="downloaded"; COMPRESSING="compressing"; UPLOADING="uploading"; COMPLETED="completed"; CANCELLED="cancelled"; FAILED="failed"; AWAITING_CONFIG="awaiting_config"


def generate_compression_id() -> str:
    """FIX A-8/M-12: ID corto para callback_data < 64 bytes."""
    return uuid.uuid4().hex[:8]


@dataclass
class CompressionId:
    value: str
    def __str__(self): return self.value
    @classmethod
    def new(cls): return cls(generate_compression_id())


@dataclass
class VideoSettings:
    resolution: str = settings.DEFAULT_VIDEO_SETTINGS["resolution"]
    crf: str = settings.DEFAULT_VIDEO_SETTINGS["crf"]
    audio_bitrate: str = settings.DEFAULT_VIDEO_SETTINGS["audio_bitrate"]
    fps: str = settings.DEFAULT_VIDEO_SETTINGS["fps"]
    preset: str = settings.DEFAULT_VIDEO_SETTINGS["preset"]
    codec: str = settings.DEFAULT_VIDEO_SETTINGS["codec"]

    @classmethod
    def from_dict(cls, d):
        defaults = settings.DEFAULT_VIDEO_SETTINGS.copy()
        defaults.update({k:v for k,v in d.items() if k in defaults})
        return cls(**defaults)

    def to_dict(self):
        return {"resolution":self.resolution,"crf":self.crf,"audio_bitrate":self.audio_bitrate,"fps":self.fps,"preset":self.preset,"codec":self.codec}

    @classmethod
    def parse_command(cls, command):
        new = {}
        for part in command.split():
            if "=" in part:
                k,v = part.split("=",1)
                if k in settings.DEFAULT_VIDEO_SETTINGS: new[k] = v
        if not new: raise ValueError("No se reconocieron parámetros válidos")
        return cls.from_dict(new)


@dataclass
class CompressionProgress:
    stage: str = ""
    current: float = 0
    total: float = 0
    percent: float = 0
    file_name: str = ""
    last_update: float = 0.0


@dataclass
class CompressionTask:
    compression_id: str
    user_id: int
    original_video_path: str
    file_name: str
    chat_id: int
    original_message_id: int
    wait_msg_id: int = 0
    wait_msg: Any = None
    caption: Optional[str] = None
    custom_settings: Optional[VideoSettings] = None
    timestamp: dt.datetime = field(default_factory=dt.datetime.now)

    def to_worker_dict(self):
        return {"compression_id":self.compression_id,"user_id":self.user_id,"original_video_path":self.original_video_path,"file_name":self.file_name,"chat_id":self.chat_id,"original_message_id":self.original_message_id,"wait_msg_id":self.wait_msg_id,"wait_msg":self.wait_msg,"caption":self.caption,"custom_settings":self.custom_settings.to_dict() if self.custom_settings else None}
