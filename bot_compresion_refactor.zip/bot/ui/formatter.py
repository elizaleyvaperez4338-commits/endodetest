"""Formateo de barras de progreso y cola."""
from __future__ import annotations
from typing import Optional


def create_progress_bar(percent, total=100, label=""):
    percent = max(0, min(100, percent))
    bl = 12; f = int(bl * percent / 100)
    bar = "█"*f + "▒"*(bl-f)
    return f"{label} [{bar}] {int(percent)}%" if label else f"[{bar}] {int(percent)}%"


def create_compression_bar(percent, bar_length=10):
    percent = max(0, min(100, percent))
    f = int(bar_length * percent / 100)
    return f"[{'⬢'*f}{'⬡'*(bar_length-f)}] {int(percent)}%"


def create_mini_progress_bar(percent, bar_length=8):
    percent = max(0, min(100, percent))
    f = int(bar_length * percent / 100)
    return f"[{'⬢'*f}{'⬡'*(bar_length-f)}] {int(percent)}%"


async def format_queue_status(active, downloaded, pending, progress_map, user_id=None, is_admin=False):
    r = "📊 **Estado de la cola**\n\n"
    r += f"🔄 **Procesos activos:** {len(active)}/1\n"
    r += f"✅ **Videos descargados:** {len(downloaded)}\n"
    active_dl = [i for i in pending if i["compression_id"] in progress_map and progress_map[i["compression_id"]].get("stage","") in ("download","download_starting")]
    r += f"\n⬇️**Descargas en curso:** {len(active_dl)}/1\n"
    if active_dl:
        for i in active_dl:
            cid = i["compression_id"]; uid = i.get("user_id")
            pct = progress_map.get(cid,{}).get("percent",0)
            r += f"• Usuario {uid} ➧ {create_mini_progress_bar(pct)}\n"
    else: r += "**• Ninguna**\n"
    r += f"\n🗜️**Compresiones activas:** {len(active)}/1\n"
    if active:
        for i, c in enumerate(active, 1):
            cid = c.get("compression_id"); uid = c.get("user_id")
            pct = progress_map.get(cid,{}).get("percent",0)
            r += f"{i}. Usuario {uid} ➧ {create_mini_progress_bar(pct)}\n"
    else: r += "**• Ninguno**\n"
    r += "\n📥 **Videos descargados esperando compresión:**\n"
    if downloaded:
        uc = {}
        for v in downloaded:
            uid = v.get("user_id"); uc[uid] = uc.get(uid,0)+1
        for i, (uid, c) in enumerate(uc.items(), 1):
            label = f"Usuario {uid} ({c} videos)" if c > 1 else f"Usuario {uid}"
            r += f"{i}. {label}\n"
    else: r += "**• Ninguno**\n"
    ua = len(set(c["user_id"] for c in active))
    ud = len(set(v["user_id"] for v in downloaded))
    r += f"\n📈 **Resumen total**:\n   • Comprimiendo: {ua} usuario(s)\n   • Descargados: {ud} usuario(s)\n"
    if is_admin:
        r += f"\n👑 **Vista de administrador:**\n• Descargas activas: {len(active_dl)}/1\n• Videos descargados en cola: {len(downloaded)}\n"
    return r
