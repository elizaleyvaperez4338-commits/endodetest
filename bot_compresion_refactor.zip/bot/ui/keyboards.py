"""Factory declarativa de teclados. FIX A-4, M-12."""
from __future__ import annotations
from typing import Optional
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup
from bot.core.config import settings


class KeyboardFactory:
    STEP_CONFIG = {
        "resolution": {"values":[("640x360","360"),("-2:480","480"),("-2:720","720")],"callback_prefix":"custom_resolution_","video_prefix":"vid_res_"},
        "crf": {"values":[(v,v) for v in settings.CUSTOM_CRF_OPTIONS],"callback_prefix":"custom_crf_","video_prefix":"vid_crf_"},
        "fps": {"values":[(v,v) for v in settings.CUSTOM_FPS_OPTIONS],"callback_prefix":"custom_fps_","video_prefix":"vid_fps_"},
        "audio": {"values":[(v,v) for v in settings.CUSTOM_AUDIO_OPTIONS],"callback_prefix":"custom_audio_","video_prefix":"vid_audio_"},
    }
    NAV_BUTTONS = {"resolution":{"back":"back_to_settings","next":"custom_next_crf"},"crf":{"back":"custom_back_resolution","next":"custom_next_fps"},"fps":{"back":"custom_back_crf","next":"custom_next_audio"},"audio":{"back":"custom_back_fps","finish":"custom_finish"}}
    VIDEO_NAV_BUTTONS = {"resolution":{"back_cb":"vid_back_res_","next_cb":"vid_next_crf_"},"crf":{"back_cb":"vid_back_crf_","next_cb":"vid_next_fps_"},"fps":{"back_cb":"vid_back_fps_","next_cb":"vid_next_audio_"},"audio":{"back_cb":"vid_back_audio_","finish_cb":"vid_finish_"}}

    @classmethod
    def quality_step(cls, step, compression_id=None, selected=None):
        config = cls.STEP_CONFIG[step]
        values = config["values"]
        is_video = compression_id is not None
        prefix = config["video_prefix"] if is_video else config["callback_prefix"]
        buttons = []
        row = []
        for value, label in values:
            text = f"✔️ {label}" if selected == value else label
            cb = f"{prefix}{compression_id}_{value}" if is_video else f"{prefix}{value}"
            row.append(InlineKeyboardButton(text, callback_data=cb))
            if len(row) == 3: buttons.append(row); row = []
        if row: buttons.append(row)
        nav = cls._build_nav(step, is_video, compression_id, selected)
        if nav: buttons.append(nav)
        if is_video:
            buttons.append([InlineKeyboardButton("❌ Cancelar", callback_data=f"vid_cancel_{compression_id}")])
        return InlineKeyboardMarkup(buttons)

    @classmethod
    def _build_nav(cls, step, is_video, cid, selected):
        if is_video:
            nav = cls.VIDEO_NAV_BUTTONS[step]
            b = [InlineKeyboardButton("🔙 Atrás", callback_data=f"{nav['back_cb']}{cid}")]
            if selected:
                if "next_cb" in nav: b.append(InlineKeyboardButton("Siguiente ➡️", callback_data=f"{nav['next_cb']}{cid}"))
                elif "finish_cb" in nav: b.append(InlineKeyboardButton("Finalizar ✅", callback_data=f"{nav['finish_cb']}{cid}"))
            return b
        else:
            nav = cls.NAV_BUTTONS[step]
            b = [InlineKeyboardButton("🔙 Atrás", callback_data=nav["back"])]
            if selected:
                if "next" in nav: b.append(InlineKeyboardButton("Siguiente ➡️", callback_data=nav["next"]))
                elif "finish" in nav: b.append(InlineKeyboardButton("Finalizar ✅", callback_data=nav["finish"]))
            return b

    @classmethod
    def quality_menu(cls):
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🗜️ Compresión General", callback_data="general_menu")],
            [InlineKeyboardButton("📱 Videos en Vertical", callback_data="reels_menu")],
            [InlineKeyboardButton("📺 Shows|Calidad media", callback_data="show_menu")],
            [InlineKeyboardButton("🎬 Anime y series animadas", callback_data="anime_menu")],
            [InlineKeyboardButton("🛠️ Personalizar Calidad 🔧", callback_data="custom_quality_start")],
        ])

    @classmethod
    def plan_menu(cls):
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🧩 Estándar", callback_data="plan_standard")],
            [InlineKeyboardButton("💎 Pro", callback_data="plan_pro")],
            [InlineKeyboardButton("👑 Premium", callback_data="plan_premium")],
        ])

    @classmethod
    def payment_methods(cls, plan):
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("USDT (BEP20)💰", callback_data=f"payment_method_usdt_{plan}")],
            [InlineKeyboardButton("MiTransfer💳", callback_data=f"payment_method_mtransfer_{plan}")],
            [InlineKeyboardButton("Saldo Móvil📱", callback_data=f"payment_method_saldo_{plan}")],
            [InlineKeyboardButton("🔙 Volver", callback_data="plan_back")],
        ])

    @classmethod
    def verify_payment(cls, pid):
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ Verificar", callback_data=f"verify_payment_{pid}")],
            [InlineKeyboardButton("🔙 Volver", callback_data=f"back_to_methods__{pid}")],
        ])

    @classmethod
    def admin_payment_review(cls, pid):
        return InlineKeyboardMarkup([[InlineKeyboardButton("✅ Aceptar", callback_data=f"admin_accept_payment_{pid}"), InlineKeyboardButton("❌ Rechazar", callback_data=f"admin_reject_payment_{pid}")]])


def get_main_menu_keyboard():
    return ReplyKeyboardMarkup([[KeyboardButton("⚙️ Settings"), KeyboardButton("📋 Planes")],[KeyboardButton("📊 Mi Plan"), KeyboardButton("ℹ️ Ayuda")],[KeyboardButton("👀 Ver Cola"), KeyboardButton("🗑️ Cancelar Cola")]], resize_keyboard=True, one_time_keyboard=False)


def get_cancel_keyboard(cid):
    return InlineKeyboardMarkup([[InlineKeyboardButton("⛔ Cancelar ⛔", callback_data=f"cancel_task_{cid}")]])


def get_quality_menu_keyboard():
    return KeyboardFactory.quality_menu()
