"""Templates de mensajes."""
from __future__ import annotations
import datetime as dt
from typing import Optional


class MessageTemplates:
    MAINTENANCE_ACTIVE = "⚙️**Bot en mantenimiento** ⚙️\n\n➥El bot está actualmente en modo mantenimiento.\n\nPor favor, espere a que termine el mantenimiento.\nUse /estado para ver el estado del bot"
    MAINTENANCE_ENABLED = "⚙️ **MANTENIMIENTO ACTIVADO** ⚙️\n\n➥El bot ahora está en modo mantenimiento:\n\n• Para desactivar, use el comando:\n/man_off"
    MAINTENANCE_DISABLED = "✅ **MANTENIMIENTO DESACTIVADO** ✅\n\n➥El bot vuelve a estar operativo para todos los usuarios."
    MAINTENANCE_ALREADY_ON = "⚠️ **El modo mantenimiento ya está activado.**"
    MAINTENANCE_ALREADY_OFF = "⚠️ **El modo mantenimiento ya está desactivado.**"
    NO_PLAN_RESPONSE = "🚫**Usted no tiene acceso para usar el bot**🚫\n⬇️**Toque para ver nuestros planes**⬇️"
    DENIED_ACCESS = "**🤖 Bot para comprimir videos**\nPuedo reducir el tamaño de los vídeos hasta un 80% o más y se verán bien sin perder tanta calidad.\n\n⬇️**Toque para ver nuestros planes**⬇️"
    BANNED = "🚫 Tu acceso ha sido revocado."
    COMPRESSION_CANCELLED = "⛔ **Compresión cancelada** ⛔"
    DOWNLOAD_CANCELLED = "⛔ **Descarga cancelada** ⛔"
    ERROR_GENERIC = "⚠️ Ocurrió un error inesperado. Intenta de nuevo."
    ERROR_FORMAT_NOT_SUPPORTED = "❌ **Formato no soportado.**\nExtensiones válidas: {extensions}"
    ERROR_MUST_REPLY_DOCUMENT = "❌ **Debes responder a un documento que sea un vídeo.**"
    ERROR_FILE_NOT_FOUND = "❌ **Error: Archivo no encontrado**"
    SETTINGS_UPDATED = "✅ **Configuración actualizada correctamente:**\n\n"
    SETTINGS_RESET = "✅ **Configuración restablecida a los valores por defecto:**\n\n"
    SETTINGS_FORMAT_HELP = "❌ **Error al actualizar la configuración.**\nFormato correcto: /calidad resolution=-2:480 crf=28 audio_bitrate=64k fps=25 preset=veryfast codec=libx264"

    @staticmethod
    def welcome(version):
        return f"**🤖 Bot para comprimir videos**\n➣**Creado por** @boyPhonk\n\n**¡Bienvenido!** Puedo reducir el tamaño de los vídeos hasta un 80% o más y se verán bien sin perder tanta calidad.\nUsa los botones del menú para interactuar conmigo.\nSi tiene duda use el botón ℹ️ Ayuda\n\n**⚙️ Versión {version} ⚙️**"

    @staticmethod
    def queue_added(file_name, position):
        return f"⏳ **Video agregado a la cola**\n\n`{file_name}`\n\n📊 **Posición en cola:** #{position}\n⏱ **Esperando slot disponible...**"

    @staticmethod
    def video_downloaded(file_name, position, eta):
        return f"╭━━━━[**🤖Compress Fast**]━━━━━╮\n┠✅ **Video descargado** ✅\n┠📁 **Archivo:** `{file_name}`\n┠📊 **Posición en cola:** #{position}\n┠🔄 **Agregado a la cola de compresión**\n┠ 🗜️**Comienza a las:** {eta}\n╰━━━━━━━━━━━━━━━━━━━━━╯"

    @staticmethod
    def compression_progress(percent, bar, compressed_size, elapsed, remaining, finish):
        return f"╭━━━━[**🤖Compress Fast**]━━━━━╮\n┠🗜️𝗖𝗼𝗺𝗽𝗿𝗶𝗺𝗶𝗲𝗻𝗱𝗼 𝗩𝗶𝗱𝗲𝗼🎬\n┠**Progreso**: {bar}\n┠**Tamaño**: {compressed_size}\n┠**Tiempo transcurrido**: {elapsed}\n┠**Tiempo restante**: {remaining}\n┠**Finaliza a las**: {finish}\n╰━━━━━━━━━━━━━━━━━━━━━╯"

    @staticmethod
    def compression_done(base_name, processing_time):
        return f"➲ **{base_name}**\n┖ ⏰ {processing_time}\n"

    @staticmethod
    def notify_group_start(username, user_id, size_mb, file_name):
        return f"🗜️ **Nuevo video recibido para comprimir**\n\n👤 **Usuario:** {username}\n🆔 **ID:** `{user_id}`\n📦 **Tamaño original:** {size_mb} MB\n📁 **Nombre:** `{file_name}`"

    @staticmethod
    def notify_group_done(username, user_id, original_mb, compressed_mb, processing_time, file_name):
        return f"✅ **Video comprimido y enviado**\n\n👤 **Usuario:** {username}\n🆔 **ID:** `{user_id}`\n📦 **Tamaño original:** {original_mb} MB\n📉 **Tamaño comprimido:** {compressed_mb} MB\n⏰ **Tiempo transcurrido:** {processing_time}\n📁 **Nombre:** `{file_name}`"

    @staticmethod
    def plan_info(plan, expires_text):
        return f"╭✠━━━━━━━━━━━━━━━━━━━━━━✠╮\n┠➣ **Tu plan actual:** {plan}\n┠➣ **Tiempo restante:** {expires_text}\n╰✠━━━━━━━━━━━━━━━━━━━━━━✠╯\n\n📋 Selecciona un plan para más información:"

    @staticmethod
    def plan_no_active():
        return "**No tienes un plan activo.**\nAdquiere un plan para usar el bot.\n\n📋 Selecciona un plan para más información:"

    @staticmethod
    def plan_activated(plan, duration_text):
        return f"✅ **Plan {plan.capitalize()} activado!**\n**Válido por {duration_text}**\n\nUse el comando /start para iniciar en el bot"

    @staticmethod
    def key_invalid(): return "❌ **Clave inválida o ya ha sido utilizada.**"
    @staticmethod
    def key_expired(): return "❌ **La clave ha expirado.**"

    @staticmethod
    def payment_request_usdt():
        return "➥ **Pago vía USDT (BEP20)**\n\n`0xa2d5ED8f66291bA5a0eADaB135C47900b81001A4`\n\n**Cuando realice la transferencia toque en\n✅ Verificar.**"

    @staticmethod
    def payment_sent_to_admin():
        return "✅ **Solicitud de compra enviada**\n\nEspera la confirmación de tu pago por el administrador.\nRecibirás una notificación cuando tu plan sea activado."

    @staticmethod
    def payment_accepted(plan): return f"✅ Tu plan **{plan.capitalize()}** ha sido activado."

    @staticmethod
    def payment_rejected(plan):
        return f"❌ **Pago rechazado**\n\nTu solicitud de pago para el plan **{plan.capitalize()}** ha sido rechazada.\n\nPor favor, verifica los datos de transferencia y vuelve a intentarlo.\nSi crees que es un error, contacta al soporte: @VirtualMix_Shop"

    @staticmethod
    def payment_admin_notification(username, user_id, plan):
        return f"**Nueva solicitud de Plan📝**\n\n👤Usuario: {username}\n🆔ID: `{user_id}`\n💠Plan: {plan.capitalize()}"

    @staticmethod
    def help_message():
        return "👨🏻‍💻 **Información**\n\n➣ **Configurar calidad**:\n• Usa el botón ⚙️ Settings\n➣ **Para comprimir un video**:\n• Envíalo directamente al bot (tanto como vídeo nativo o como documento de vídeo)\n• Extensiones válidas: mp4, mkv, avi, ts, mov, flv, wmv, webm, m4v, 3gp, mpeg, mpg, 3g2, rm, rmvb, vob, f4v, ogv, drc, nsv, mpe, m2v\n➣ **Ver planes**:\n• Usa el botón 📋 Planes\n➣ **Ver tu estado**:\n• Usa el botón 📊 Mi Plan\n➣ **Usa** /start **para iniciar en el bot nuevamente o para actualizar**\n➣ **Ver cola de compresión**:\n• Usa el botón 👀 Ver Cola\n➣ **Cancelar videos de la cola**:\n• Usa el botón 🗑️ Cancelar Cola\n➣ **Para ver su configuración de compresión actual use**: /calidad\n➣ **Para ver el estado del bot use**: /estado\n• Simplemente envía el documento y el bot lo procesará automáticamente.\n➣ **Comando** /mode **agregado.**\n• Ahora pueden elegir entre si comprimír directo sin configurar calidad o configurarle la calidad a cada video antes de comprimír\n\n**NUEVO SISTEMA:**\n• Los videos se descargan inmediatamente y se agregarán a la cola de compresión\n• Progreso en tiempo real"
