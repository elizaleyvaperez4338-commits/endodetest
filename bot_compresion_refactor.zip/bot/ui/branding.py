from bot.core.config import settings
WATERMARK = settings.watermark_text
BOT_CAPTION = f"Creado por @boyPhonk · v{settings.version}"
