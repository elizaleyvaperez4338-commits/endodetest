"""Servicio de mantenimiento. FIX C-3."""
from __future__ import annotations
from bot.core.state import app_state
from bot.core.config import settings
from bot.core.logging import logger


class MaintenanceService:
    async def is_active(self): return await app_state.get_maintenance()
    async def activate(self):
        if await self.is_active(): return
        await app_state.set_maintenance(True); logger.info("Mantenimiento activado")
    async def deactivate(self):
        if not await self.is_active(): return
        await app_state.set_maintenance(False); logger.info("Mantenimiento desactivado")
    async def check_and_notify(self, user_id, chat_id, message_text, send_func, delete_after=10):
        if not await self.is_active(): return False
        if settings.is_admin(user_id): return False
        from bot.ui.messages import MessageTemplates
        if message_text:
            await send_func(chat_id, MessageTemplates.MAINTENANCE_ACTIVE)
        else:
            msg = await send_func(chat_id, MessageTemplates.MAINTENANCE_ACTIVE)
            from bot.services.message_service import MessageService
            await MessageService().delete_after(msg, delete_after)
        return True
