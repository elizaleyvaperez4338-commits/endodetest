"""Servicio de descarga."""
from __future__ import annotations
import asyncio, os, time
from typing import Optional
import pyrogram.errors

from bot.core.app import app
from bot.core.logging import logger
from bot.core.state import app_state
from bot.db.repositories import downloaded_videos_repo, pending_repo
from bot.services.message_service import MessageService
from bot.services.stats_service import StatsService
from bot.utils.file_naming import unique_download_path
from bot.utils.time_utils import now_utc


class DownloadService:
    def __init__(self, messages=None):
        self._messages = messages or MessageService()

    async def download(self, compression_id, user_id, chat_id, original_message_id, file_obj, file_name, wait_msg, caption=None, custom_settings=None, progress_callback=None):
        pending = await pending_repo.get(compression_id)
        if not pending:
            if wait_msg:
                try: await wait_msg.delete()
                except Exception: pass
            return False
        from bot.core.config import settings
        original_video_path = str(unique_download_path(compression_id, file_name, settings.temp_dir))
        try:
            current_task = asyncio.current_task()
            await app_state.register_cancelable(compression_id, "download", task=current_task, original_message_id=original_message_id, progress_message_id=wait_msg.id if wait_msg else None)
            await app_state.update_progress(compression_id, "download_starting", 0, 100, 0, file_name)
            start_time = time.time()
            downloaded_path = await app.download_media(file_obj, file_name=os.path.basename(original_video_path), progress=progress_callback, progress_args=(wait_msg, "DESCARGA", start_time))
            if await app_state.is_cancelled(compression_id):
                if downloaded_path and os.path.exists(downloaded_path): await asyncio.to_thread(os.remove, downloaded_path)
                raise asyncio.CancelledError("Descarga cancelada")
            fs = await asyncio.to_thread(os.path.getsize, downloaded_path)
            await StatsService().record_download(fs)
            await pending_repo.remove(compression_id)
            await downloaded_videos_repo.add({"user_id":user_id,"compression_id":compression_id,"file_path":downloaded_path,"file_name":file_name,"chat_id":chat_id,"original_message_id":original_message_id,"wait_msg_id":wait_msg.id if wait_msg else None,"original_caption":caption,"custom_settings":custom_settings,"timestamp":now_utc()})
            logger.info(f"Video descargado: {downloaded_path}")
            return True
        except asyncio.CancelledError:
            if os.path.exists(original_video_path): await asyncio.to_thread(os.remove, original_video_path)
            await pending_repo.remove(compression_id)
            raise
        except Exception as e:
            logger.error(f"Error en descarga {compression_id}: {e}", exc_info=True)
            if os.path.exists(original_video_path): await asyncio.to_thread(os.remove, original_video_path)
            await pending_repo.remove(compression_id)
            return False
        finally:
            await app_state.remove_active_message(compression_id)
