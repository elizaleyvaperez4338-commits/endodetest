"""Servicio de broadcast con cola serial. FIX A-16."""
from __future__ import annotations
import asyncio
from dataclasses import dataclass
from typing import Optional
from bot.core.app import app
from bot.core.logging import logger
from bot.core.state import app_state
from bot.db.repositories import users_repo


@dataclass
class BroadcastMessage:
    admin_id: int
    text: Optional[str] = None
    photo: Optional[str] = None
    video: Optional[str] = None
    caption: Optional[str] = None


class BroadcastService:
    def __init__(self):
        self._queue: asyncio.Queue = asyncio.Queue()
        self._running = False

    async def enqueue(self, msg):
        await self._queue.put(msg)
        if not self._running: app_state.spawn_background(self._worker())

    async def _worker(self):
        self._running = True
        try:
            while not self._queue.empty():
                msg = await self._queue.get()
                try: await self._send_broadcast(msg)
                except Exception as e: logger.error(f"Error en broadcast: {e}", exc_info=True)
                finally: self._queue.task_done()
        finally: self._running = False

    async def _send_broadcast(self, msg):
        users = await users_repo.list_with_plan(["standard","pro","premium","ultra"])
        sent=0; failed=0
        for u in users:
            uid = u["user_id"]
            try:
                if msg.text: await app.send_message(uid, msg.text)
                elif msg.photo: await app.send_photo(uid, msg.photo, caption=msg.caption)
                elif msg.video: await app.send_video(uid, msg.video, caption=msg.caption)
                sent += 1; await asyncio.sleep(0.05)
            except Exception as e:
                logger.warning(f"Broadcast fallido a {uid}: {e}"); failed += 1
        try: await app.send_message(msg.admin_id, f"📤 **Broadcast completado**\n\n✅ Enviados: {sent}\n❌ Fallidos: {failed}")
        except Exception: pass
        return sent, failed
