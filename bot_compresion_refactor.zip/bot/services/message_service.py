"""Servicio de mensajes. FIX M-13, M-23."""
from __future__ import annotations
import asyncio, time
import pyrogram.errors
from bot.core.app import app
from bot.core.logging import logger


class MessageService:
    _protect_cache = {}
    _cache_ttl = 60.0

    async def _should_protect(self, uid):
        now = time.time()
        cached = self._protect_cache.get(uid)
        if cached and now - cached[1] < self._cache_ttl: return cached[0]
        self._protect_cache[uid] = (True, now)
        return True

    async def send_protected_message(self, chat_id, text, **kwargs):
        p = await self._should_protect(chat_id)
        return await app.send_message(chat_id, text, protect_content=p, **kwargs)

    async def send_protected_video(self, chat_id, video, caption=None, **kwargs):
        p = await self._should_protect(chat_id)
        return await app.send_video(chat_id, video, caption=caption, protect_content=p, **kwargs)

    async def send_protected_photo(self, chat_id, photo, caption=None, **kwargs):
        p = await self._should_protect(chat_id)
        return await app.send_photo(chat_id, photo, caption=caption, protect_content=p, **kwargs)

    async def send_protected_document(self, chat_id, document, caption=None, **kwargs):
        p = await self._should_protect(chat_id)
        return await app.send_document(chat_id, document, caption=caption, protect_content=p, **kwargs)

    async def send_auto_delete_message(self, chat_id, text, delete_after=3, **kwargs):
        msg = await self.send_protected_message(chat_id, text, **kwargs)
        await self.delete_after(msg, delete_after)
        return msg

    @staticmethod
    async def delete_after(message, seconds):
        await asyncio.sleep(seconds)
        try: await message.delete()
        except pyrogram.errors.MessageIdInvalid: pass
        except Exception as e: logger.warning(f"No se pudo eliminar mensaje: {e}")

    @staticmethod
    async def safe_edit(message, text, reply_markup=None):
        try: await message.edit(text, reply_markup=reply_markup)
        except pyrogram.errors.MessageNotModified: pass
        except Exception as e: logger.warning(f"Error editando mensaje: {e}")
