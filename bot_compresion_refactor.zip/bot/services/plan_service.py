"""Servicio de planes. FIX M-2, M-21."""
from __future__ import annotations
import datetime as dt
from typing import Optional
from bot.core.logging import logger
from bot.models.user import PLAN_DURATIONS


def _users_repo():
    from bot.db.repositories import users_repo
    return users_repo


def _temp_keys_repo():
    from bot.db.repositories import temp_keys_repo
    return temp_keys_repo


class PlanService:
    async def get_user_plan(self, user_id):
        return await _users_repo().get(user_id)

    async def is_active(self, user_id):
        plan = await self.get_user_plan(user_id)
        if not plan or not plan.get("plan"): return False
        expires = plan.get("expires_at")
        if not expires: return True
        if expires.tzinfo is None: expires = expires.replace(tzinfo=dt.timezone.utc)
        now = dt.datetime.now(dt.timezone.utc)
        return expires > now

    async def set_plan(self, user_id, plan, expires_at=None, notify=False):
        if plan not in PLAN_DURATIONS: return False
        await _users_repo().set_plan(user_id, plan, expires_at)
        logger.info(f"Plan {plan} activado para {user_id}")
        return True

    async def activate_key(self, user_id, key):
        key_data = await _temp_keys_repo().find_valid(key)
        if not key_data: return False, "invalid"
        now = dt.datetime.now(dt.timezone.utc)
        ek = key_data.get("expires_at")
        if ek:
            if ek.tzinfo is None: ek = ek.replace(tzinfo=dt.timezone.utc)
            if ek < now: return False, "expired"
        await _temp_keys_repo().mark_used(key_data["_id"])
        dv = key_data["duration_value"]
        du = key_data["duration_unit"].lower()
        if du == "minutes": exp = now + dt.timedelta(minutes=dv)
        elif du == "hours": exp = now + dt.timedelta(hours=dv)
        elif du == "days": exp = now + dt.timedelta(days=dv)
        else: return False, f"invalid_unit:{du}"
        plan = key_data["plan"]
        ok = await self.set_plan(user_id, plan, exp)
        if not ok: return False, "set_plan_failed"
        return True, plan

    async def get_queue_limit(self, user_id):
        from bot.core.config import settings
        doc = await self.get_user_plan(user_id)
        plan = doc.get("plan") if doc else None
        return settings.queue_limit_for_plan(plan)
