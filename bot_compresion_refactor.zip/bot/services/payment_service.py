"""Servicio de pagos. FIX M-20."""
from __future__ import annotations
import datetime as dt
from typing import Optional
from bson import ObjectId
from bot.core.app import app
from bot.core.config import settings
from bot.core.logging import logger
from bot.db.repositories import payments_repo
from bot.models.payment import PaymentRequest, PaymentStatus
from bot.services.message_service import MessageService
from bot.services.plan_service import PlanService
from bot.services.user_cache import user_cache
from bot.ui.keyboards import KeyboardFactory
from bot.ui.messages import MessageTemplates


class PaymentService:
    def __init__(self, messages=None):
        self._messages = messages or MessageService()
        self._plan_service = PlanService()

    async def create_request(self, user_id, plan, method): return await payments_repo.create(user_id, plan, method)
    async def get(self, pid): return await payments_repo.get(pid)

    async def receive_receipt(self, user_id, photo_file_id, photo_size=None):
        payment = await payments_repo.find_waiting_receipt(user_id)
        if not payment: return False
        if not photo_file_id: return False
        await payments_repo.update_status(payment["_id"], "pending_admin", file_id=photo_file_id)
        if payment.get("instruction_msg_id"):
            try: await app.delete_messages(chat_id=user_id, message_ids=[payment["instruction_msg_id"]])
            except Exception as e: logger.warning(f"No se pudo eliminar instrucción: {e}")
        confirmation = await self._messages.send_protected_message(user_id, MessageTemplates.payment_sent_to_admin())
        await payments_repo.update_status(payment["_id"], "pending_admin", confirmation_msg_id=confirmation.id)
        await self._notify_admins(user_id, payment["plan"], photo_file_id)
        return True

    async def admin_accept(self, pid):
        payment = await self.get(pid)
        if not payment or payment.status != PaymentStatus.PENDING_ADMIN: return False, "not_pending"
        ok = await self._plan_service.set_plan(payment.user_id, payment.plan, notify=True)
        if not ok: return False, "set_plan_failed"
        if payment.confirmation_msg_id:
            try: await app.delete_messages(chat_id=payment.user_id, message_ids=[payment.confirmation_msg_id])
            except Exception: pass
        await payments_repo.delete(pid)
        await self._messages.send_protected_message(payment.user_id, MessageTemplates.payment_accepted(payment.plan))
        return True, payment.plan

    async def admin_reject(self, pid):
        payment = await self.get(pid)
        if not payment or payment.status != PaymentStatus.PENDING_ADMIN: return False, "not_pending"
        await self._messages.send_protected_message(payment.user_id, MessageTemplates.payment_rejected(payment.plan))
        if payment.confirmation_msg_id:
            try: await app.delete_messages(chat_id=payment.user_id, message_ids=[payment.confirmation_msg_id])
            except Exception: pass
        await payments_repo.delete(pid)
        return True, payment.plan

    async def _notify_admins(self, user_id, plan, photo_file_id):
        u = await user_cache.get_username(user_id)
        caption = MessageTemplates.payment_admin_notification(u, user_id, plan)
        payment = await payments_repo.find_waiting_receipt(user_id)
        kb = KeyboardFactory.admin_payment_review(payment["_id"]) if payment else None
        for admin_id in settings.admins_ids:
            try: await app.send_photo(chat_id=admin_id, photo=photo_file_id, caption=caption, reply_markup=kb)
            except Exception as e: logger.error(f"Error notificando admin {admin_id}: {e}")
