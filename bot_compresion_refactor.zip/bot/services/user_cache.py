"""Cache de usernames. FIX C-5."""
from __future__ import annotations
import asyncio, time
from typing import Iterable
from bot.core.app import app
from bot.core.logging import logger


class UserCache:
    def __init__(self, ttl=3600):
        self._cache = {}
        self._ttl = ttl
        self._lock = asyncio.Lock()

    async def get_username(self, user_id):
        now = time.time()
        async with self._lock:
            cached = self._cache.get(user_id)
            if cached and now - cached[1] < self._ttl: return cached[0]
        try:
            u = await app.get_users(user_id)
            name = f"@{u.username}" if u.username else f"Usuario {user_id}"
        except Exception: name = f"Usuario {user_id}"
        async with self._lock: self._cache[user_id] = (name, now)
        return name

    async def get_usernames(self, user_ids):
        uids = list(set(user_ids))
        results = await asyncio.gather(*[self.get_username(u) for u in uids], return_exceptions=True)
        return {u: (r if isinstance(r, str) else f"Usuario {u}") for u, r in zip(uids, results)}

    def invalidate(self, uid): self._cache.pop(uid, None)


user_cache = UserCache()
