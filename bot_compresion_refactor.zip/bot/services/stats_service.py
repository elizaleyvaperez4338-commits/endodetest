from bot.db.repositories import daily_stats_repo


class StatsService:
    async def record_download(self, fs): await daily_stats_repo.inc_download(fs)
    async def record_compressed(self): await daily_stats_repo.inc_compressed()
    async def record_recovery(self, n=1): await daily_stats_repo.inc_recovery(n)
    async def today(self): return await daily_stats_repo.get_today()
