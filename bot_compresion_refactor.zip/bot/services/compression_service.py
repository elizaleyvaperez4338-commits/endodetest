"""Servicio de compresión. Reemplaza compress_video_from_path (326 líneas). FIX C-1, A-12, A-13, C-7, C-5."""
from __future__ import annotations
import asyncio, datetime as dt, os, time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import pyrogram.errors

from bot.core.app import app
from bot.core.config import settings
from bot.core.logging import logger
from bot.core.state import app_state
from bot.db.repositories import active_compressions_repo, downloaded_videos_repo, pending_repo, users_repo
from bot.models.compression import CompressionTask, VideoSettings
from bot.services.message_service import MessageService
from bot.services.stats_service import StatsService
from bot.services.user_cache import user_cache
from bot.ui.formatter import create_compression_bar
from bot.ui.messages import MessageTemplates
from bot.ui.keyboards import get_cancel_keyboard
from bot.utils.ffmpeg_wrapper import FFmpegError, FFmpegWrapper
from bot.utils.file_naming import unique_compressed_path
from bot.utils.text_utils import sanitize_filename
from bot.utils.time_utils import format_time, now_cuba, sizeof_fmt


@dataclass
class CompressionResult:
    success: bool
    compression_id: str
    compressed_path: Optional[str] = None
    compressed_size: int = 0
    duration: float = 0
    processing_time: float = 0
    error: Optional[str] = None


class CompressionService:
    def __init__(self, ffmpeg=None, messages=None, stats=None):
        self._ffmpeg = ffmpeg or FFmpegWrapper()
        self._messages = messages or MessageService()
        self._stats = stats or StatsService()

    async def compress(self, task: CompressionTask) -> CompressionResult:
        start_time = time.time()
        cid = task.compression_id
        if not os.path.exists(task.original_video_path):
            await self._messages.send_protected_message(task.chat_id, MessageTemplates.ERROR_FILE_NOT_FOUND)
            await downloaded_videos_repo.remove(cid)
            return CompressionResult(False, cid, error="file not found")
        vs = await self._resolve_settings(task)
        msg = await self._create_progress_message(task)
        await active_compressions_repo.add({"compression_id":cid,"user_id":task.user_id,"file_name":task.file_name,"start_time":dt.datetime.now(dt.timezone.utc)})
        await app_state.register_cancelable(cid, "ffmpeg", progress_message_id=msg.id if msg else None)
        original_size = await asyncio.to_thread(os.path.getsize, task.original_video_path)
        await self._notify_group_start(task, original_size)
        temp_dir = os.path.dirname(task.original_video_path)
        base_name = sanitize_filename(task.caption or os.path.splitext(task.file_name)[0], 100)
        if not task.caption: base_name = f"{base_name}_compressed"
        compressed_path = str(unique_compressed_path(task.file_name, temp_dir, suffix="" if task.caption else "_compressed"))
        thumb = None
        try:
            async def on_progress(p, c, t):
                await self._update_progress_message(msg, cid, p, compressed_path, start_time, t)
            result = await self._ffmpeg.compress(task.original_video_path, compressed_path, vs, on_progress=on_progress, cancel_event=None)
            thumb = await self._ffmpeg.generate_thumbnail(compressed_path, f"{compressed_path}_thumb.jpg", result.duration)
            await self._send_compressed_video(task, msg, compressed_path, thumb, result, original_size)
            await self._stats.record_compressed()
            await users_repo.increment_compressed(task.user_id)
            pt = time.time() - start_time
            await self._notify_group_done(task, original_size, result.compressed_size, format_time(pt), base_name)
            return CompressionResult(True, cid, compressed_path, result.compressed_size, result.duration, pt)
        except asyncio.CancelledError:
            await self._messages.send_auto_delete_message(task.chat_id, MessageTemplates.COMPRESSION_CANCELLED, reply_to_message_id=task.original_message_id)
            return CompressionResult(False, cid, error="cancelled")
        except FFmpegError as e:
            await self._messages.send_auto_delete_message(task.chat_id, "⛔ **Compresión fallida** ⛔", reply_to_message_id=task.original_message_id)
            return CompressionResult(False, cid, error=str(e))
        except Exception as e:
            logger.exception(f"Error inesperado en compresión {cid}")
            return CompressionResult(False, cid, error=str(e))
        finally:
            await self._ffmpeg.cleanup_files(task.original_video_path, compressed_path, thumb)
            await active_compressions_repo.remove(cid)
            await downloaded_videos_repo.remove(cid)
            await app_state.unregister_cancelable(cid)
            await app_state.remove_progress(cid)
            await app_state.remove_active_message(cid)
            if msg:
                try: await msg.delete()
                except Exception: pass
            if task.wait_msg:
                try: await task.wait_msg.delete()
                except Exception: pass

    async def _resolve_settings(self, task):
        if task.custom_settings: return task.custom_settings
        from bot.db.repositories import user_settings_repo
        return await user_settings_repo.get_video_settings(task.user_id)

    async def _create_progress_message(self, task):
        try:
            msg = await app.send_message(chat_id=task.chat_id, text=MessageTemplates.compression_progress(0, create_compression_bar(0), "0B", "00:00", "00:00", "Calculando..."), reply_to_message_id=task.original_message_id, reply_markup=get_cancel_keyboard(task.compression_id))
            await app_state.set_active_message(task.compression_id, msg.id)
            return msg
        except Exception as e:
            logger.warning(f"No se pudo crear mensaje de progreso: {e}")
            return None

    async def _update_progress_message(self, msg, cid, percent, compressed_path, start_time, duration):
        if app_state.should_throttle(cid, 1.5): return
        try:
            cs = 0
            if os.path.exists(compressed_path): cs = await asyncio.to_thread(os.path.getsize, compressed_path)
            el = time.time() - start_time
            rem = (el/percent)*(100-percent) if percent > 0 else 0
            fin = "Calculando..." if rem <= 0 else (now_cuba() + dt.timedelta(seconds=rem)).strftime("%I:%M %p")
            await msg.edit(MessageTemplates.compression_progress(percent, create_compression_bar(percent), sizeof_fmt(cs), format_time(el), format_time(rem), fin), reply_markup=get_cancel_keyboard(cid))
            await app_state.update_progress(cid, "compression", percent, 100, percent, "")
        except pyrogram.errors.MessageNotModified: pass
        except Exception as e: logger.warning(f"Error editando progreso: {e}")

    async def _send_compressed_video(self, task, msg, compressed_path, thumb, ffmpeg_result, original_size):
        pt = format_time(ffmpeg_result.duration)
        caption = MessageTemplates.compression_done(sanitize_filename(task.caption or task.file_name, 100), pt)
        kwargs = {"caption":caption, "duration":int(ffmpeg_result.duration), "reply_to_message_id":task.original_message_id}
        if thumb and os.path.exists(thumb): kwargs["thumb"] = thumb
        await self._messages.send_protected_video(chat_id=task.chat_id, video=compressed_path, **kwargs)

    async def _notify_group_start(self, task, original_size):
        try:
            u = await user_cache.get_username(task.user_id)
            await app.send_message(chat_id=settings.notification_group_id, text=MessageTemplates.notify_group_start(u, task.user_id, original_size//(1024*1024), task.file_name))
        except Exception as e: logger.warning(f"No se pudo notificar al grupo: {e}")

    async def _notify_group_done(self, task, original_size, compressed_size, processing_time, base_name):
        try:
            u = await user_cache.get_username(task.user_id)
            await app.send_message(chat_id=settings.notification_group_id, text=MessageTemplates.notify_group_done(u, task.user_id, original_size//(1024*1024), compressed_size//(1024*1024), processing_time, base_name))
        except Exception as e: logger.warning(f"No se pudo notificar al grupo (done): {e}")

    async def cancel(self, cid):
        info = await app_state.get_cancelable(cid)
        if not info: return False
        if info.process:
            try: info.process.terminate()
            except ProcessLookupError: pass
        return True
