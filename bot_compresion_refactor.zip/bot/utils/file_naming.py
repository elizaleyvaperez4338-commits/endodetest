"""Utilidades de nombres de archivo."""
from __future__ import annotations
import os
from pathlib import Path
from bot.utils.text_utils import sanitize_filename


def unique_compressed_path(original_name, temp_dir, suffix="_compressed"):
    base, ext = os.path.splitext(original_name)
    safe_base = sanitize_filename(base)
    if not safe_base: safe_base = "video_comprimido"
    safe_base = f"{safe_base}{suffix}"
    p = Path(temp_dir) / f"{safe_base}.mp4"
    c = 1
    while p.exists():
        p = Path(temp_dir) / f"{safe_base}_{c}.mp4"; c += 1
    return p


def unique_download_path(compression_id, original_name, temp_dir):
    base, ext = os.path.splitext(original_name)
    return Path(temp_dir) / f"{compression_id}_{base}{ext}"
