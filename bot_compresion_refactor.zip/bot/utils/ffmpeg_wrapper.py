"""Wrapper async para FFmpeg. FIX C-1, A-14, A-18, A-20."""
from __future__ import annotations
import asyncio, os, re
from dataclasses import dataclass
from pathlib import Path
from typing import AsyncIterator, Callable, Optional

from bot.core.config import settings
from bot.core.logging import logger
from bot.models.compression import VideoSettings


class FFmpegError(Exception): pass


@dataclass
class FFmpegResult:
    success: bool
    compressed_path: str
    compressed_size: int
    duration: float
    exit_code: int
    error: Optional[str] = None


class FFmpegWrapper:
    TIME_PATTERN = re.compile(r"time=(\d+:\d+:\d+\.\d+)")

    def __init__(self, binary=None, ffprobe_binary=None):
        self.binary = binary or settings.ffmpeg_binary
        self.ffprobe_binary = ffprobe_binary or settings.ffprobe_binary

    async def probe_duration(self, video_path):
        cmd = [self.ffprobe_binary,"-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",video_path]
        try:
            proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            stdout, _ = await proc.communicate()
            if proc.returncode != 0: return 0.0
            return float(stdout.decode().strip() or "0")
        except Exception as e:
            logger.error(f"Error probing duration: {e}")
            return 0.0

    def _build_compress_command(self, input_path, output_path, vs):
        drawtext = self._build_drawtext_filter()
        vf_parts = [f"scale={vs.resolution}"]
        if drawtext: vf_parts.append(drawtext)
        return [self.binary,"-nostdin","-loglevel","error","-y","-i",input_path,"-vf",",".join(vf_parts),"-crf",vs.crf,"-b:a",vs.audio_bitrate,"-r",vs.fps,"-preset",vs.preset,"-c:v",vs.codec,output_path]

    def _build_drawtext_filter(self):
        font_path = settings.watermark_font_path
        if not font_path or not os.path.exists(font_path):
            logger.warning("Fontfile no encontrado, drawtext deshabilitado")
            return None
        text = settings.watermark_text.replace(":", r"\:").replace("'", r"\'")
        return f"drawtext=text='{text}':x=w-tw-10:y=10:fontsize=20:fontcolor=white:fontfile={font_path}"

    async def compress(self, input_path, output_path, video_settings, on_progress=None, cancel_event=None):
        if not os.path.exists(input_path):
            raise FFmpegError(f"Input file not found: {input_path}")
        duration = await self.probe_duration(input_path)
        cmd = self._build_compress_command(input_path, output_path, video_settings)
        proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
        try:
            async for line in self._read_stderr(proc, cancel_event):
                await self._process_progress_line(line, duration, on_progress)
            await proc.wait()
            if cancel_event and cancel_event.is_set():
                if os.path.exists(output_path): await asyncio.to_thread(os.remove, output_path)
                raise asyncio.CancelledError("Compresión cancelada")
            if proc.returncode != 0:
                raise FFmpegError(f"FFmpeg exited with code {proc.returncode}")
            size = await asyncio.to_thread(os.path.getsize, output_path)
            dur = await self.probe_duration(output_path)
            if duration > 0 and dur > 0:
                diff = abs(dur - duration) / duration * 100
                if diff > 10:
                    logger.warning(f"Posible compresión incompleta: original={duration:.2f}s, comprimido={dur:.2f}s")
            return FFmpegResult(success=True, compressed_path=output_path, compressed_size=size, duration=dur, exit_code=proc.returncode)
        except asyncio.CancelledError:
            try: proc.kill(); await proc.wait()
            except ProcessLookupError: pass
            if os.path.exists(output_path): await asyncio.to_thread(os.remove, output_path)
            raise

    async def _read_stderr(self, proc, cancel_event):
        while True:
            if cancel_event and cancel_event.is_set(): return
            if proc.stderr.at_eof(): break
            line = await proc.stderr.readline()
            if not line:
                if proc.returncode is not None: break
                continue
            yield line.decode("utf-8", errors="replace")

    async def _process_progress_line(self, line, duration, on_progress):
        if "error" in line.lower() or "warning" in line.lower():
            logger.warning(f"FFmpeg: {line.strip()}")
        m = self.TIME_PATTERN.search(line)
        if not m or duration <= 0 or on_progress is None: return
        ts = m.group(1)
        try:
            h, mn, s = ts.split(":")
            cur = int(h)*3600 + int(mn)*60 + float(s)
            pct = min(100.0, (cur/duration)*100)
            await on_progress(pct, cur, duration)
        except (ValueError, ZeroDivisionError): pass

    async def generate_thumbnail(self, video_path, thumbnail_path, duration):
        seek = duration // 2 if duration > 0 else 0
        cmd = [self.binary,"-nostdin","-loglevel","error","-ss",str(seek),"-i",video_path,"-vf","scale=320:-1","-vframes","1","-y",thumbnail_path]
        try:
            proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
            await proc.wait()
            if proc.returncode != 0: return None
            return thumbnail_path if os.path.exists(thumbnail_path) else None
        except Exception as e:
            logger.error(f"Error generating thumbnail: {e}")
            return None

    async def cleanup_files(self, *paths):
        for p in paths:
            if not p: continue
            try: await asyncio.to_thread(Path(p).unlink, True)
            except Exception as e: logger.warning(f"No se pudo eliminar {p}: {e}")
