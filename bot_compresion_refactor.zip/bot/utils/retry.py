"""Decoradores de retry y manejo de errores. FIX C-2."""
from __future__ import annotations
import asyncio, functools
from typing import Callable
import pyrogram.errors
from bot.core.logging import logger


def retry_on_flood(max_retries=3):
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            for attempt in range(max_retries + 1):
                try: return await func(*args, **kwargs)
                except pyrogram.errors.FloodWait as e:
                    if attempt == max_retries: raise
                    await asyncio.sleep(e.value + 1)
                except pyrogram.errors.RPCError: raise
        return wrapper
    return decorator


def safe_handler(func):
    @functools.wraps(func)
    async def wrapper(client, update, *args, **kwargs):
        try: return await func(client, update, *args, **kwargs)
        except asyncio.CancelledError: raise
        except (KeyboardInterrupt, SystemExit): raise
        except pyrogram.errors.FloodWait as e:
            await asyncio.sleep(e.value + 1)
        except pyrogram.errors.MessageNotModified: pass
        except pyrogram.errors.MessageIdInvalid: pass
        except pyrogram.errors.UserIsBlocked: pass
        except pyrogram.errors.RPCError as e:
            logger.error(f"Telegram RPC en {func.__name__}: {e}")
        except Exception:
            logger.exception(f"Error inesperado en {func.__name__}")
            try:
                chat = getattr(getattr(update, "message", update), "chat", None)
                if chat: await client.send_message(chat.id, "⚠️ Ocurrió un error inesperado. Intenta de nuevo.")
            except Exception: pass
    return wrapper
