"""Utilidades de texto. FIX M-19."""
from __future__ import annotations
import html, re, unicodedata


def sanitize_filename(name, max_length=100):
    if not name: return "video_comprimido"
    n = unicodedata.normalize("NFKD", name).encode("ascii","ignore").decode("ascii")
    safe = re.sub(r"[^a-zA-Z0-9 _-]", "_", n)
    safe = safe.strip().replace(" ", "_")
    safe = re.sub(r"_+", "_", safe)
    if not safe: safe = "video_comprimido"
    return safe[:max_length]


def sanitize_caption(caption):
    if not caption: return ""
    n = unicodedata.normalize("NFKD", caption).encode("ascii","ignore").decode("ascii")
    cleaned = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", n)
    return cleaned.strip()


def escape_html(text):
    return html.escape(text or "", quote=False)
