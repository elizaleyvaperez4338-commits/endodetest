"""Utilidades de tiempo. FIX M-2/M-3."""
from __future__ import annotations
import datetime as dt
import zoneinfo
from typing import Optional
from bot.core.config import settings


def _tz(): return zoneinfo.ZoneInfo(settings.timezone)
def now_utc(): return dt.datetime.now(dt.timezone.utc)
def now_cuba(): return dt.datetime.now(_tz())
def today_str(): return now_cuba().strftime("%Y-%m-%d")


def format_time(seconds):
    if seconds is None or not isinstance(seconds, (int,float)): return "00:00"
    if seconds < 0: return "00:00"
    total = int(seconds)
    m, s = divmod(total, 60)
    h, m = divmod(m, 60)
    if h > 0: return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def sizeof_fmt(num, suffix="B"):
    for unit in ["","K","M","G","T","P","E","Z"]:
        if abs(num) < 1024.0: return "%3.2f%s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.2f%s%s" % (num, "Yi", suffix)


def format_eta(estimated_start):
    if estimated_start is None: return "Sin calcular..."
    now = now_cuba()
    if estimated_start.tzinfo is None: estimated_start = estimated_start.replace(tzinfo=_tz())
    diff = (estimated_start - now).total_seconds()
    if diff < 60: return "Calculando..."
    return estimated_start.strftime("%I:%M %p")
