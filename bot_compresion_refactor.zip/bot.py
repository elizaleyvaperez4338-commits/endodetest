#!/usr/bin/env python3
"""Entrypoint del bot de compresión. Antes: 4,588 líneas. Ahora: 3 líneas."""
from bot.main import main
import asyncio

if __name__ == "__main__":
    asyncio.run(main())
